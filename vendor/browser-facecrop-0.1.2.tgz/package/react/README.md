# Optional React adapter

`react/index.js` is CommonJS and stays outside the core package entry point. The application owns camera acquisition, the video element, and camera tracks. The hook owns one capture session for its mounted instance and never starts automatically.

## Bundler integration

When the application stages the distribution, import the React hook and pass the generated module bridge as `coreApi`:

```js
import {useFaceCropSession} from 'browser-facecrop/react';
import * as Facecrop from './facecrop-generated/facecrop.js';
import facecropAssets from './facecrop-generated/facecropAssets.json';

const capture = useFaceCropSession({
  video,
  assetBaseUrl: new URL(
    facecropAssets.publicSubpath.slice(1),
    new URL('/study_assets/my-study/', window.location.origin)
  ).href,
  transport: Facecrop.createJatosTransport(jatosApi),
  context: {task: 'speech'}
}, Facecrop);
```

Replace `/study_assets/my-study/` with the application's deployment directory, or `/` for a root deployment. The staged bridge initializes the core distribution for the bundler. Injecting it avoids having this adapter resolve or load a second copy of the core. See the [staging workflow](../docs/integration.md#2-stage-and-serve-the-runtime) for the matching filesystem and URL setup.

## Lifecycle and options

The hook accepts the same options as `createCaptureSession`, except `video` may be absent initially and supplied on a later render. Options other than `video` and `onEvent` are read on the first render. The session is created once the video becomes available; changing `onEvent` takes effect on subsequent renders. Remount the hook owner (for example, change its React `key`) to create a session with different options or a different video.

Preparation is optional and explicit. Call `prepare()` when you want to probe support and warm up resources before recording. Calling `start()` also prepares automatically. Inspect each resolved result's `status`, `reasonCode`, `failureCode`, `reason`, and artifact outcomes; operations can resolve with a structured failure result. Invalid session options can throw during session construction. That construction occurs in the hook's React effect, so a `try/catch` around button handlers or a core event callback does not catch it. Use an error boundary around the hook owner if the application needs to present construction exceptions.

The returned object contains `session`, `status`, `result`, `prepare`, `start`, `stop`, and `abort`. The adapter does not acquire or stop camera tracks. Await `stop()` before navigation when finalized artifacts matter. Without a shared upload queue, stop waits for persistence attempts; with one, stop waits until artifacts are accepted by the queue and they may settle later. Unmount calls `abort()` as best-effort cleanup and does not wait for it; accepted shared-queue uploads continue after abort, while work not yet accepted is discarded. Keep the host upload tracker alive through those later settlements.

The hook forwards core events to `onEvent`. Use `artifact_registered` and `artifact_settled` for application upload tracking; each is emitted once per upload ID. Existing `artifact` events retain retry progress. An in-flight write can settle after unmount aborts the session, so keep upload tracking in application state that outlives the recording component.

## Example

[`FacecropRecorder.jsx`](../examples/react/FacecropRecorder.jsx) accepts an injected `coreApi`, shows preparation as an optional probe, displays structured results, and awaits normal stop before invoking its finalization callback. The host passes a playing video and the matching runtime `assetBaseUrl`.

React 16.8 through 19 is an optional peer dependency. You may also bind the injected API once with `createReactHooks(Facecrop)`; its returned hook has the same behavior. Omitting injection uses the package's built default core, but does not deploy its runtime assets. The package publishes declarations generated from source JSDoc; see the [API reference](../docs/api.md) and [documentation workflow](../docs/documentation.md).
