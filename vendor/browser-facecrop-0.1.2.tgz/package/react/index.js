// @ts-check
'use strict';

/** @typedef {import('../src/PublicTypes').CaptureOptions} CaptureOptions */
/** @typedef {import('../src/PublicTypes').CaptureSession} CaptureSession */
/** @typedef {import('../src/PublicTypes').CaptureResult} CaptureResult */
/**
 * First-render session inputs, with a video that may arrive after mount.
 * Only video and onEvent are read on subsequent renders; remount to change other options.
 * @typedef {Omit<CaptureOptions,'video'> & {video?:HTMLVideoElement|null}} ReactCaptureOptions
 */
/** Injected core boundary; framework-independent and compatible with the staged bridge.
 * @typedef {{createCaptureSession:(options:CaptureOptions)=>CaptureSession}} CoreApi
 */
/**
 * Minimal React hook implementation accepted by the factory, including test doubles.
 * Structural typing keeps the emitted contract independent of React type packages.
 * @typedef {object} ReactHooksApi
 * @property {<T>(initialValue:T)=>{current:T}} useRef Mutable hook-local reference.
 * @property {<T>(initialValue:T)=>[T,(value:T|((previous:T)=>T))=>void]} useState Hook-local state.
 * @property {(effect:()=>void|(()=>void),dependencies:ReadonlyArray<unknown>)=>void} useEffect Effect and synchronous cleanup; cleanup cannot return a promise.
 */
/**
 * Reactive state and explicit controls for one capture. The adapter does not own camera tracks.
 * @typedef {object} CaptureHookHandle
 * @property {CaptureSession|null} session Created after mount when video becomes available.
 * @property {import('../src/PublicTypes').CaptureStatus|'idle'} status Idle before session creation; a new session reports disabled.
 * @property {CaptureResult|null} result Latest observed result; absent before session creation.
 * @property {()=>Promise<CaptureResult|null>} prepare Explicitly probe and warm up; null before a session exists.
 * @property {()=>Promise<CaptureResult|null>} start Prepare automatically and start; null before a session exists.
 * @property {()=>Promise<CaptureResult|null>} stop Await final persistence without a shared queue, or queue admission when one is configured; null before a session exists.
 * @property {()=>Promise<CaptureResult|null>} abort Discard work not yet accepted by a shared queue; accepted jobs and in-flight writes can still persist.
 */
/** Hook factory result, bound to a fixed core API.
 * @typedef {{useFaceCropSession:(options:ReactCaptureOptions)=>CaptureHookHandle}} ReactCaptureHooks
 */

const React = require('react');

/**
 * Bind the lifecycle hook to a supplied core API and optional React hook implementation.
 * This factory creates no capture; use the returned hook in a mounted component.
 * @param {CoreApi} coreApi Framework-neutral capture API, including a staged module bridge.
 * @param {ReactHooksApi} [reactApi] Defaults to the installed React implementation.
 * @returns {ReactCaptureHooks} Hook bound to the supplied core.
 * @throws {TypeError} If createCaptureSession is missing.
 */
function createReactHooks(coreApi, reactApi = React) {
    if (!coreApi || typeof coreApi.createCaptureSession !== 'function') {
        throw new TypeError('coreApi.createCaptureSession is required');
    }
    const {useEffect, useRef, useState} = reactApi;

    /**
     * Own one capture per mounted hook instance, without acquiring/stopping camera tracks.
     * Options are fixed on the first render except video may arrive later and onEvent
     * stays current. Remount to change capture identity, options, or video. Preparation
     * is explicit; unmount aborts without awaiting and cannot retract persisted writes.
     * @param {ReactCaptureOptions} options Session inputs; only video may be absent initially.
     * @returns {CaptureHookHandle} Reactive result and explicit lifecycle controls.
     * @throws {TypeError} If options are absent or session construction inputs are invalid.
     */
    function useFaceCropSession(options) {
        if (!options || typeof options !== 'object') throw new TypeError('options are required');
        /** @type {{current:ReactCaptureOptions|null}} */
        const optionsRef = useRef(null);
        if (optionsRef.current === null) {
            optionsRef.current = Object.assign({}, options);
            delete optionsRef.current.video;
            delete optionsRef.current.onEvent;
        }
        const onEventRef = useRef(options.onEvent);
        onEventRef.current = options.onEvent;
        const video = options.video || null;
        /** @type {{current:CaptureSession|null}} */
        const sessionRef = useRef(null);
        const resultState = useState(/** @type {CaptureResult|null} */ (null));
        const result = resultState[0];
        const setResult = resultState[1];
        const mountedRef = useRef(false);
        useEffect(() => {
            mountedRef.current = true;
            if (!sessionRef.current && video) {
                sessionRef.current = coreApi.createCaptureSession(Object.assign({}, optionsRef.current, {
                    video,
                    onEvent: event => {
                        try {
                            if (typeof onEventRef.current === 'function') onEventRef.current(event);
                        } finally {
                            const current = sessionRef.current;
                            if (current && mountedRef.current) setResult(current.getResult());
                        }
                    }
                }));
                setResult(sessionRef.current.getResult());
            }
        }, [video]);
        useEffect(() => () => {
            mountedRef.current = false;
            const session = sessionRef.current;
            sessionRef.current = null;
            if (session) {
                try { Promise.resolve(session.abort()).catch(() => {}); } catch (_) { /* best effort unmount cleanup */ }
            }
        }, []);

        const session = sessionRef.current;
        const refresh = () => {
            const current = sessionRef.current;
            if (!current) return null;
            const next = current.getResult();
            if (mountedRef.current) setResult(next);
            return next;
        };
        /** @param {'prepare'|'start'|'stop'|'abort'} method @returns {Promise<CaptureResult|null>} */
        const invoke = method => {
            const current = sessionRef.current;
            if (!current) return Promise.resolve(null);
            let value;
            try { value = current[method](); } catch (error) { refresh(); return Promise.reject(error); }
            refresh();
            return Promise.resolve(value).then(value => {
                refresh();
                return value;
            }, error => {
                refresh();
                throw error;
            });
        };
        const currentResult = session ? result || session.getResult() : null;
        return {
            session,
            status: currentResult ? currentResult.status : 'idle',
            result: currentResult,
            prepare: () => invoke('prepare'),
            start: () => invoke('start'),
            stop: () => invoke('stop'),
            abort: () => invoke('abort')
        };
    }

    return {useFaceCropSession};
}

/**
 * Bind the lifecycle hook to the built package distribution, loading it lazily.
 * Build the distribution before using this factory from a vendored checkout.
 * @param {ReactHooksApi} [reactApi] Defaults to installed React.
 * @returns {ReactCaptureHooks} Hook bound to the package core.
 */
function createReactHooksWithDefaultCore(reactApi = React) {
    // Keep the core import lazy so consumers can inject a staged or bundled API.
    return createReactHooks(require('../dist/facecrop.module.js'), reactApi);
}

/**
 * Own one capture for a mounted React component, with explicit preparation and unmount abort.
 * Supply session options on the first render; video may arrive later and onEvent stays
 * current. Remount to change other inputs. Await stop() before navigating when final
 * persistence matters. With a shared queue, stop waits for admission and uploads may settle
 * later; keep host tracking alive. React does not await unmount cleanup, and abort cannot
 * retract accepted queue jobs or in-flight writes.
 * @param {ReactCaptureOptions} options Session inputs, without camera ownership.
 * @param {CoreApi} [coreApi] Inject a staged core, or omit to use the built package core.
 * @returns {CaptureHookHandle} Reactive status/results and controls, resolving null before a session exists.
 * @throws {TypeError} If required options/core API are invalid.
 */
function useFaceCropSession(options, coreApi) {
    const api = coreApi || require('../dist/facecrop.module.js');
    return createReactHooks(api).useFaceCropSession(options);
}

module.exports = {createReactHooks, createReactHooksWithDefaultCore, useFaceCropSession};
