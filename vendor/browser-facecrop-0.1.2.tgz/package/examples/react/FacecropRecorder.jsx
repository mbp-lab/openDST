import React, {useState} from 'react';
import {useFaceCropSession} from 'browser-facecrop/react';

const EMPTY_CONTEXT = Object.freeze({});

/**
 * Pass the staged Facecrop module as coreApi. The host application supplies a
 * playing video; this component never acquires or stops camera tracks.
 */
export function FacecropRecorder({video, coreApi, transport, assetBaseUrl, context = EMPTY_CONTEXT, onEvent, onFinalized}) {
    const [operationError, setOperationError] = useState(null);
    const capture = useFaceCropSession({
        video,
        filenamePrefix: 'example',
        context,
        assetBaseUrl,
        transport,
        onEvent // Optional application observer; tracking state should outlive this component.
    }, coreApi);

    async function run(operation) {
        setOperationError(null);
        try {
            const result = await operation();
            if (result && result.status !== 'ready' && result.status !== 'capturing' && result.status !== 'complete') {
                setOperationError(formatResult(result));
            }
            return result;
        } catch (error) {
            setOperationError(error.message || String(error));
            return null;
        }
    }

    async function stop() {
        const result = await run(capture.stop);
        if (result && onFinalized) {
            try { await onFinalized(result); }
            catch (error) { setOperationError(error.message || String(error)); }
        }
    }

    return <div>
        <span>Facecrop: {capture.status}</span>
        <button type="button" onClick={() => run(capture.prepare)} disabled={!capture.session || capture.status !== 'disabled'}>
            Prepare facecrop (optional probe)
        </button>
        <button type="button" onClick={() => run(capture.start)} disabled={!capture.session || capture.status !== 'disabled' && capture.status !== 'ready'}>
            Start facecrop
        </button>
        <button type="button" onClick={stop} disabled={capture.status !== 'capturing'}>
            Stop and save
        </button>
        {operationError && <pre role="alert">{operationError}</pre>}
        {capture.result && <details>
            <summary>Latest structured result</summary>
            <pre>{JSON.stringify(capture.result, null, 2)}</pre>
        </details>}
    </div>;
}

function formatResult(result) {
    return JSON.stringify({
        status: result.status,
        reasonCode: result.reasonCode,
        failureCode: result.failureCode,
        reason: result.reason,
        artifacts: result.artifacts,
        observerErrors: result.observerErrors
    }, null, 2);
}
