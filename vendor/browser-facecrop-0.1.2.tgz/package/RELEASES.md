# Release record

The index keeps each release title separate from its publication status and
records the tag, notes, and asset metadata. Last synchronized: 2026-10-08.
Release descriptions live in versioned files for reuse as GitHub release bodies.

## v0.1.2 - Shared uploads, diagnostics, and configurable output

- Version: `0.1.2`; tag: `v0.1.2`.
- Status: tagged; GitHub Release not yet published.
- Runtime asset directory SHA-256: `8fa71c983f9de390926180d50d6e9dbec1c8a67ac71651a7f23910c2a30ce2c0`.
- [Release notes](releases/v0.1.2.md).
- The locally built tarball and checksum are draft artifacts, not published-release assets.

## v0.1.1 - Standalone package and editor declarations

- Version: `0.1.1`; tag: `v0.1.1`.
- Published: `2026-10-07T14:26:55Z`; status: prerelease.
- Tagged commit: `99204f10864c64839691237da822755f24314d7c`.
- [GitHub release](https://github.com/mbp-lab/browser-facecrop/releases/tag/v0.1.1) · [Mirrored notes](releases/v0.1.1.md).

| Asset | Bytes | SHA-256 |
|---|---:|---|
| [browser-facecrop-0.1.1.tgz](https://github.com/mbp-lab/browser-facecrop/releases/download/v0.1.1/browser-facecrop-0.1.1.tgz) | 1286707 | `6af06cb252108670dac7e30a56934d8ec85c43475f9517755c364cc58aeaacc8` |
| [browser-facecrop-0.1.1.tgz.sha256](https://github.com/mbp-lab/browser-facecrop/releases/download/v0.1.1/browser-facecrop-0.1.1.tgz.sha256) | 111 | `11954ed531e300967beaacc90f4a46852b77dbb60128dd12da2b9e2001062b58` |

## v0.1.0 — Initial release

- Version: `0.1.0`; tag: `v0.1.0`.
- Published: `2026-10-07T12:37:54Z`; status: prerelease.
- Tagged commit: `b59ece0fffc8fe1db052e30077be630455c6a335`.
- [GitHub release](https://github.com/mbp-lab/browser-facecrop/releases/tag/v0.1.0) · [Mirrored notes](releases/v0.1.0.md).

| Asset | Bytes | SHA-256 |
|---|---:|---|
| [browser-facecrop-0.1.0.tgz](https://github.com/mbp-lab/browser-facecrop/releases/download/v0.1.0/browser-facecrop-0.1.0.tgz) | 1253843 | `d695c060799c91f8c87069d13ac93bcb3f66c25a5f3d1eb1204def38f6319cce` |
| [browser-facecrop-0.1.0.tgz.sha256](https://github.com/mbp-lab/browser-facecrop/releases/download/v0.1.0/browser-facecrop-0.1.0.tgz.sha256) | 93 | `5edb6c2667e9aea80adcb8af178718ab9e7f91d8ff4295fc8cc580adb56bc9e4` |

## Maintaining this record

Before publication, keep the current version marked **Unreleased** and edit its
draft notes. Once GitHub confirms publication, record the actual title, timestamp,
prerelease status, tag commit, and uploaded asset metadata here. The runtime asset
directory hash and the tarball SHA-256 are different values; record each accurately.

If published notes or assets change on GitHub, mirror the observed update here in
a new commit. Never label a local package or a Git tag alone as a published release.
