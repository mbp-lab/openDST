/** Stage a verified browser distribution into explicit application destinations. */
const fs = require('fs');
const path = require('path');
const {verifyDistribution} = require('./verify-distribution.cjs');

/**
 * Promote staged files as one rollback-capable replacement operation.
 * Temporary files and destinations must support rename on the same filesystem;
 * keep `workDirectory` on the destination filesystem to avoid cross-device rename failures.
 *
 * @param {{temporary: string, destination: string}[]} replacements Ordered staged-to-final paths.
 * @param {string} workDirectory Directory for backup files and rollback recovery.
 * @param {(source: string, destination: string) => void} [rename=fs.renameSync] Rename operation, injectable for fault tests.
 * @returns {void}
 * @throws {Error} Promotion error; incomplete rollback records `recoveryDirectory` on the error.
 * @internal
 */
function promoteFiles(replacements, workDirectory, rename = fs.renameSync) {
    const backups = [];
    const promoted = [];
    try {
        replacements.forEach(({temporary, destination}) => {
            fs.mkdirSync(path.dirname(destination), {recursive: true});
            if (fs.existsSync(destination)) {
                const backup = path.join(workDirectory, `backup-${backups.length}`);
                rename(destination, backup);
                backups.push({backup, destination});
            }
            rename(temporary, destination);
            promoted.push(destination);
        });
    } catch (error) {
        const recoveryErrors = [];
        promoted.reverse().forEach(destination => {
            try { fs.rmSync(destination, {recursive: true, force: true}); }
            catch (recoveryError) { recoveryErrors.push(`${destination}: ${recoveryError.message}`); }
        });
        backups.reverse().forEach(({backup, destination}) => {
            if (!fs.existsSync(backup)) return;
            try { rename(backup, destination); }
            catch (recoveryError) { recoveryErrors.push(`${destination} (backup ${backup}): ${recoveryError.message}`); }
        });
        if (recoveryErrors.length) {
            error.recoveryDirectory = workDirectory;
            error.message += `. Rollback was incomplete; recovery files remain at ${workDirectory}. Restore: ${recoveryErrors.join('; ')}`;
        }
        throw error;
    }
}

/**
 * Copy a distribution tree without replacing an existing destination.
 *
 * @param {string} source Source tree.
 * @param {string} destination New destination path.
 * @returns {void}
 * @throws {Error} If the copy fails or the destination already exists.
 * @internal
 */
function copyTree(source, destination) {
    fs.cpSync(source, destination, {recursive: true, errorOnExist: true, force: false});
}

/**
 * Wrap a UMD build in an ES module bridge for bundlers that consume named exports.
 *
 * @param {string} umdSource Built UMD source text.
 * @returns {string} ES module source exposing the stable core exports.
 * @internal
 */
function createModuleBridge(umdSource) {
    return '/* eslint-disable */\n' +
        'const facecropExports = (() => {\n' +
        'const module = {exports: {}};\n' +
        'const exports = module.exports;\n' +
        umdSource +
        '\nreturn module.exports;\n})();\n' +
        ['createCaptureSession', 'createUploadQueue', 'validateConfiguration', 'createJatosTransport',
            'PATCH_VIDEO_FORMAT_VERSION', 'FACE_EVENTS_FORMAT_VERSION']
            .map(name => `export const ${name} = facecropExports.${name};\n`).join('');
}

/**
 * Verify and stage the browser runtime plus generated application entry metadata.
 * Runtime assets are installed under the immutable content hash. The staging,
 * public, and generated directories must share a filesystem for rename-based promotion.
 *
 * @param {string} distributionRoot Built distribution directory.
 * @param {object} destinations Application output, public asset, URL prefix, and staging roots.
 * @param {string} destinations.generatedDirectory Application-generated entry output directory.
 * @param {string} destinations.publicRoot Public immutable asset root.
 * @param {string} destinations.publicSubpath URL prefix, beginning and ending with `/`.
 * @param {string} destinations.workRoot Temporary staging directory root.
 * @param {object} [options] Injectable filesystem operations.
 * @param {(source: string, destination: string) => void} [options.rename] Rename operation, injectable for fault tests.
 * @returns {{assetDirectory: string, publicSubpath: string}} Verified immutable asset location.
 * @throws {TypeError|Error} Invalid destinations, invalid distribution, or staging/promotion failure.
 */
function stageDistribution(distributionRoot, destinations, options = {}) {
    const {generatedDirectory, publicRoot, publicSubpath, workRoot} = destinations;
    if (!generatedDirectory || !publicRoot || !workRoot || !publicSubpath || !publicSubpath.startsWith('/') || !publicSubpath.endsWith('/')) {
        throw new TypeError('Staging requires generatedDirectory, publicRoot, workRoot and a publicSubpath beginning and ending with /');
    }
    const manifest = verifyDistribution(distributionRoot);
    const generatedEntry = path.join(generatedDirectory, 'facecrop.js');
    const generatedMetadata = path.join(generatedDirectory, 'facecropAssets.json');
    const stagedPublic = path.join(publicRoot, manifest.assetDirectory);
    const stageDirectory = fs.mkdtempSync(path.join(workRoot, '.facecrop-stage-'));
    let createdPublic = false;
    let preserveStageDirectory = false;
    try {
        if (fs.existsSync(stagedPublic)) {
            const existing = verifyDistribution(stagedPublic, {allowVersionMismatch: true});
            if (existing.assetDirectory !== manifest.assetDirectory) throw new Error('Existing staged facecrop directory does not match its hash path');
        } else {
            const temporaryPublic = path.join(stageDirectory, 'public-assets');
            copyTree(distributionRoot, temporaryPublic);
            verifyDistribution(temporaryPublic);
            fs.mkdirSync(publicRoot, {recursive: true});
            (options.rename || fs.renameSync)(temporaryPublic, stagedPublic);
            createdPublic = true;
        }

        const temporaryEntry = path.join(stageDirectory, 'facecrop.js');
        const temporaryMetadata = path.join(stageDirectory, 'facecropAssets.json');
        const entry = fs.readFileSync(path.join(distributionRoot, 'facecrop.module.js'), 'utf8');
        fs.writeFileSync(temporaryEntry, entry);
        fs.writeFileSync(temporaryMetadata, JSON.stringify({
            publicSubpath: `${publicSubpath}${manifest.assetDirectory}/`
        }, null, 2) + '\n');
        promoteFiles([
            {temporary: temporaryEntry, destination: generatedEntry},
            {temporary: temporaryMetadata, destination: generatedMetadata}
        ], stageDirectory, options.rename || fs.renameSync);
        return {assetDirectory: manifest.assetDirectory, publicSubpath: `${publicSubpath}${manifest.assetDirectory}/`};
    } catch (error) {
        if (error.recoveryDirectory === stageDirectory) preserveStageDirectory = true;
        if (createdPublic) fs.rmSync(stagedPublic, {recursive: true, force: true});
        throw error;
    } finally {
        if (!preserveStageDirectory) fs.rmSync(stageDirectory, {recursive: true, force: true});
    }
}

module.exports = {promoteFiles, stageDistribution, createModuleBridge};
