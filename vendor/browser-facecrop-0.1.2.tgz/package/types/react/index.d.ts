export type CaptureOptions = import("../src/PublicTypes").CaptureOptions;
export type CaptureSession = import("../src/PublicTypes").CaptureSession;
export type CaptureResult = import("../src/PublicTypes").CaptureResult;
/**
 * First-render session inputs, with a video that may arrive after mount.
 * Only video and onEvent are read on subsequent renders; remount to change other options.
 */
export type ReactCaptureOptions = Omit<CaptureOptions, "video"> & {
    video?: HTMLVideoElement | null;
};
/**
 * Injected core boundary; framework-independent and compatible with the staged bridge.
 */
export type CoreApi = {
    createCaptureSession: (options: CaptureOptions) => CaptureSession;
};
/**
 * Minimal React hook implementation accepted by the factory, including test doubles.
 * Structural typing keeps the emitted contract independent of React type packages.
 */
export type ReactHooksApi = {
    /**
     * Mutable hook-local reference.
     */
    useRef: <T>(initialValue: T) => {
        current: T;
    };
    /**
     * Hook-local state.
     */
    useState: <T>(initialValue: T) => [T, (value: T | ((previous: T) => T)) => void];
    /**
     * Effect and synchronous cleanup; cleanup cannot return a promise.
     */
    useEffect: (effect: () => void | (() => void), dependencies: ReadonlyArray<unknown>) => void;
};
/**
 * Reactive state and explicit controls for one capture. The adapter does not own camera tracks.
 */
export type CaptureHookHandle = {
    /**
     * Created after mount when video becomes available.
     */
    session: CaptureSession | null;
    /**
     * Idle before session creation; a new session reports disabled.
     */
    status: import("../src/PublicTypes").CaptureStatus | "idle";
    /**
     * Latest observed result; absent before session creation.
     */
    result: CaptureResult | null;
    /**
     * Explicitly probe and warm up; null before a session exists.
     */
    prepare: () => Promise<CaptureResult | null>;
    /**
     * Prepare automatically and start; null before a session exists.
     */
    start: () => Promise<CaptureResult | null>;
    /**
     * Await final persistence without a shared queue, or queue admission when one is configured; null before a session exists.
     */
    stop: () => Promise<CaptureResult | null>;
    /**
     * Discard work not yet accepted by a shared queue; accepted jobs and in-flight writes can still persist.
     */
    abort: () => Promise<CaptureResult | null>;
};
/**
 * Hook factory result, bound to a fixed core API.
 */
export type ReactCaptureHooks = {
    useFaceCropSession: (options: ReactCaptureOptions) => CaptureHookHandle;
};
/**
 * Bind the lifecycle hook to a supplied core API and optional React hook implementation.
 * This factory creates no capture; use the returned hook in a mounted component.
 * @param {CoreApi} coreApi Framework-neutral capture API, including a staged module bridge.
 * @param {ReactHooksApi} [reactApi] Defaults to the installed React implementation.
 * @returns {ReactCaptureHooks} Hook bound to the supplied core.
 * @throws {TypeError} If createCaptureSession is missing.
 */
export function createReactHooks(coreApi: CoreApi, reactApi?: ReactHooksApi): ReactCaptureHooks;
/**
 * Bind the lifecycle hook to the built package distribution, loading it lazily.
 * Build the distribution before using this factory from a vendored checkout.
 * @param {ReactHooksApi} [reactApi] Defaults to installed React.
 * @returns {ReactCaptureHooks} Hook bound to the package core.
 */
export function createReactHooksWithDefaultCore(reactApi?: ReactHooksApi): ReactCaptureHooks;
/**
 * Own one capture for a mounted React component, with explicit preparation and unmount abort.
 * Supply session options on the first render; video may arrive later and onEvent stays
 * current. Remount to change other inputs. Await stop() before navigating when final
 * persistence matters. With a shared queue, stop waits for admission and uploads may settle
 * later; keep host tracking alive. React does not await unmount cleanup, and abort cannot
 * retract accepted queue jobs or in-flight writes.
 * @param {ReactCaptureOptions} options Session inputs, without camera ownership.
 * @param {CoreApi} [coreApi] Inject a staged core, or omit to use the built package core.
 * @returns {CaptureHookHandle} Reactive status/results and controls, resolving null before a session exists.
 * @throws {TypeError} If required options/core API are invalid.
 */
export function useFaceCropSession(options: ReactCaptureOptions, coreApi?: CoreApi): CaptureHookHandle;
