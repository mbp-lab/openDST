/**
 * Validate two-plane NV12 storage before reading it. Dimensions must be even;
 * `layouts` describes Y then interleaved UV, with offsets/strides in bytes.
 * @internal
 * @param {Uint8Array} bytes
 * @param {number} width visible source width
 * @param {number} height visible source height
 * @param {Nv12PlaneLayout[]} layouts Y and UV plane layouts
 * @returns {Nv12PlaneLayout[]}
 */
export function validateNv12Buffer(bytes: Uint8Array, width: number, height: number, layouts: Nv12PlaneLayout[]): Nv12PlaneLayout[];
/** @internal Return output dimensions after a clockwise quarter/half turn. */
export function rotatedDimensions(width: any, height: any, rotation: any): {
    width: any;
    height: any;
};
/** @internal Convert full-range BT.709 NV12 while preserving legacy pixel math. */
export function convertFullRangeBt709Nv12ToRgba(input: any): RgbaFrame;
/** @internal Convert limited-range BT.709 NV12 using nominal video levels. */
export function convertLimitedRangeBt709Nv12ToRgba(input: any): RgbaFrame;
/**
 * Compare only the 90° and 270° orientations against a rendered luminance
 * thumbnail. A tie deterministically chooses clockwise rotation.
 * @internal
 * @param {Nv12Frame & {reference: Uint8Array, referenceWidth?: number, referenceHeight?: number, fullRange?:boolean}} input
 * @returns {{rotation: 90|270, clockwiseDistance: number, counterclockwiseDistance: number}}
 */
export function selectQuarterTurnByLuminance({ bytes, width, height, layouts, reference, referenceWidth, referenceHeight, fullRange }: Nv12Frame & {
    reference: Uint8Array;
    referenceWidth?: number;
    referenceHeight?: number;
    fullRange?: boolean;
}): {
    rotation: 90 | 270;
    clockwiseDistance: number;
    counterclockwiseDistance: number;
};
/** @internal Luminance thumbnail dimension used by orientation calibration. */
export const ORIENTATION_REFERENCE_SIZE: 32;
/**
 * Byte offset and row stride for one NV12 plane.
 */
export type Nv12PlaneLayout = {
    offset: number;
    stride: number;
};
/**
 * Packed or padded NV12 storage and its visible plane geometry.
 */
export type Nv12Frame = {
    bytes: Uint8Array;
    width: number;
    height: number;
    layouts: Nv12PlaneLayout[];
};
/**
 * Tightly packed RGBA pixels; rgbx is a historical property name.
 */
export type RgbaFrame = {
    rgbx: Uint8Array;
    width: number;
    height: number;
};
