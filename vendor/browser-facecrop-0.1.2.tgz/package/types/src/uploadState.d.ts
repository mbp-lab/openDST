export namespace UPLOAD_STATUS {
    let PENDING: string;
    let SUCCEEDED: string;
    let FAILED: string;
}
/**
 * States recognized by the host upload tracker. The sink's richer artifact
 * ledger also reports `discarded`, `not_attempted`, and `uncertain` outcomes.
 */
export type UploadTrackerStatus = "pending" | "succeeded" | "failed";
