/**
 * Probe browser APIs against an already presented frame, including a real
 * VideoFrame copy/normalization attempt. The probe closes its temporary frame;
 * it does not acquire, stop, or otherwise control the application's stream.
 * @internal
 * @param {HTMLVideoElement} video
 * @returns {Promise<{supported:boolean,capability: import('./PublicTypes').Capability,source:{width:number|null,height:number|null,readyState:number|null},frameNormalization?:Object,reason?:string,error?:Error}>}
 */
export function probeFaceCropCapability(video: HTMLVideoElement): Promise<{
    supported: boolean;
    capability: import("./PublicTypes").Capability;
    source: {
        width: number | null;
        height: number | null;
        readyState: number | null;
    };
    frameNormalization?: any;
    reason?: string;
    error?: Error;
}>;
export namespace FACE_CROP_STATUS {
    let DISABLED: string;
    let UNSUPPORTED: string;
    let CAPTURING: string;
    let COMPLETE: string;
    let INCOMPLETE: string;
}
/** @internal Number of detector warmup frames per analysis worker before capture starts. */
export const FACE_DETECTION_WARMUP_FRAMES: 3;
/**
 * Main-thread RPC adapter for one face-crop worker. Requests are serialized so
 * each response resolves the sole pending request. A successful postMessage
 * transfers ownership of listed buffers/frames; before transfer, failures
 * close frames locally, while the analysis worker closes them after receipt.
 * @internal
 */
export class PipelineWorker {
    constructor(assetBaseUrl: any, diagnostics?: boolean, onDiagnostic?: null, identity?: string);
    worker: Worker;
    diagnostics: boolean;
    onDiagnostic: any;
    identity: string;
    pending: any;
    queue: any[];
    closed: boolean;
    receive(message: any): void;
    releaseFrame(request: any): void;
    diagnostic(event: any, details: any, severity?: string): void;
    fail(error: any): void;
    /** @param {import('./FaceCropPipeline.worker').WorkerRequest['type']} type @param {Object} payload @param {Transferable[]} transfer */
    request(type: import("./FaceCropPipeline.worker").WorkerRequest["type"], payload?: any, transfer?: Transferable[]): Promise<any>;
    pump(): void;
    /** @param {import('./FaceCropPipeline.worker').InitializePayload} payload @returns {Promise<{}>} */
    initialize(payload: import("./FaceCropPipeline.worker").InitializePayload): Promise<{}>;
    /**
     * @internal Transfers the VideoFrame to the analysis worker, which closes it;
     * the normalized `rgbx` result buffer is transferred back to the caller.
     * @param {import('./FaceCropPipeline.worker').ProcessFramePayload} payload
     * @returns {Promise<import('./FaceCropPipeline.worker').AnalysisResult>}
     */
    processFrame(payload: import("./FaceCropPipeline.worker").ProcessFramePayload): Promise<import("./FaceCropPipeline.worker").AnalysisResult>;
    /**
     * Transfer detaches `rgbx.buffer` from this side; assembly returns ordered
     * commits and any newly sealed parts.
     * @param {import('./FaceCropPipeline.worker').AnalysisResult} payload
     * @returns {Promise<import('./FaceCropPipeline.worker').ProcessAnalysisResponse>}
     */
    processAnalysisResult(payload: import("./FaceCropPipeline.worker").AnalysisResult): Promise<import("./FaceCropPipeline.worker").ProcessAnalysisResponse>;
    /**
     * Transfer detaches the sealed frame bytes; the encoder returns transferable
     * gzip bytes and encoding duration.
     * @param {import('./FaceCropPipeline.worker').FaceCropPart} payload
     * @returns {Promise<import('./FaceCropPipeline.worker').EncodingResponse>}
     */
    encodePart(payload: import("./FaceCropPipeline.worker").FaceCropPart): Promise<import("./FaceCropPipeline.worker").EncodingResponse>;
    /** @param {import('./FaceCropPipeline.worker').WarmupPayload} payload @returns {Promise<import('./FaceCropPipeline.worker').WarmupResponse>} */
    warmup(payload: import("./FaceCropPipeline.worker").WarmupPayload): Promise<import("./FaceCropPipeline.worker").WarmupResponse>;
    /** @returns {Promise<import('./FaceCropPipeline.worker').FinishResponse>} */
    finish(): Promise<import("./FaceCropPipeline.worker").FinishResponse>;
    terminate(): void;
    close(): Promise<void>;
}
/**
 * Coordinates the capture lifecycle while leaving camera ownership with the
 * host application. Lifecycle progresses idle → starting → prepared →
 * capturing → stopping → terminal (unsupported/incomplete/complete status is
 * separate). `stop()` drains callbacks, worker queues, and uploads before
 * producing a manifest for a started capture; `abort()` discards queued work and may report
 * in-flight transport outcomes as uncertain.
 * @internal
 */
export class FaceCropCaptureController {
    /** @param {ControllerOptions} options */
    constructor({ video, studyResultId, studyPage, videoCounter, captureId: providedCaptureId, configuration, uploadTracker, uploadResultFile, uploadQueue, onStatus, onDiagnostic, assetBaseUrl, filenamePrefix, context, onArtifact, createPipelineWorker }: ControllerOptions);
    uploadTracker: {
        registerUpload: (id: string) => void;
        settleUpload: (id: string, status: import("./uploadState").UploadTrackerStatus) => void;
    };
    onStatus: (metadata: Omit<import("./PublicTypes").StatusEvent, "type" | "reasonCode">) => void;
    onDiagnostic: ((event: string, details?: any, severity?: string, source?: string) => void) | undefined;
    createPipelineWorker: () => PipelineWorker;
    sink: FaceCropSink;
    uploadResultFile: ((payload: Blob | string, filename: string) => unknown) | undefined;
    aborted: boolean;
    started: boolean;
    onArtifact: (event: import("./PublicTypes").ArtifactEvent) => void;
    abortPromise: Promise<any> | null;
    /** @type {import('./PublicTypes').Statistics['accounting']} Stage counts reconcile submitted→processed, accepted→sealed, sealed→encoded, encoded→persisted. */
    accounting: import("./PublicTypes").Statistics["accounting"];
    state: string;
    /** @type {CaptureStatus} */
    status: CaptureStatus;
    startPromise: Promise<import("./PublicTypes").CaptureStatus> | null;
    preparePromise: Promise<any> | null;
    stopPromise: Promise<any> | null;
    frameWait: {
        callbackId: any;
        resolve: () => void;
    } | {
        callbackId: any;
        resolve: (value: any) => void;
    } | null;
    captureLoop: Promise<void> | null;
    analysisWorkers: any[];
    assemblyWorker: PipelineWorker | null;
    encoderWorker: PipelineWorker | null;
    inFlight: Map<any, any>;
    encodingJobs: Map<any, any>;
    assemblyBufferedResults: number;
    nextSequence: number;
    nextWorker: number;
    incompleteReason: any;
    captureId: string;
    acceptedFrames: number;
    skippedFrames: number;
    lastPresentedFrame: any;
    lastPresentationTimeUs: number | null;
    faceDetections: number;
    faceDetectionMisses: number;
    frameTimings: any;
    encodingTimings: any;
    detectorWarmup: {
        requested: number;
        completed: number;
        totalMs: number;
        meanMs: null;
    };
    /** @type {Capability} */
    capability: Capability;
    source: {
        width: number | null;
        height: number | null;
        readyState: number | null;
    } | {
        width: any;
        height: any;
        readyState: any;
    } | null;
    /** @type {import('./PublicTypes').SourceFailure|null} */
    sourceFailure: import("./PublicTypes").SourceFailure | null;
    frameNormalization: any;
    /** @type {ManifestResult|null} Upload outcome, not serialized manifest content. */
    manifest: ManifestResult | null;
    frameCallbacks: number;
    nextProgressLogFrame: number;
    diagnostic(event: any, details?: {}, severity?: string, source?: string): void;
    /** Start preparation and capture once; repeated calls share the same promise. @returns {Promise<import('./PublicTypes').CaptureStatus>} */
    start(): Promise<import("./PublicTypes").CaptureStatus>;
    /** Prepare capability, workers, and detector warmup without starting callbacks. @returns {Promise<import('./PublicTypes').CaptureStatus>} */
    prepare(): Promise<import("./PublicTypes").CaptureStatus>;
    waitForPresentedFrame(): Promise<any>;
    waitForVideoReady(): Promise<any>;
    prepareInternal(): Promise<any>;
    startInternal(): Promise<import("./PublicTypes").CaptureStatus>;
    /** Gracefully drain submitted work, persist artifacts, and write the manifest. */
    stop(): Promise<any>;
    stopInternal(): Promise<any>;
    /** Cancel callbacks, terminate workers, discard queued uploads, and settle best-effort. */
    abort(): Promise<any>;
    captureFrames(): Promise<void>;
    /**
     * Await the next presented frame. `presentationTime` is the timestamp
     * authority, converted from milliseconds to integer microseconds; callback
     * gaps are counted separately and are not assigned a cause.
     */
    waitForFrame(): Promise<any>;
    cancelFrameWait(): void;
    recordSkippedFrames(metadata: any): void;
    processFrame(metadata: any, wallClockMs?: number, presentationTimeUs?: null): Promise<void>;
    processAnalysisFrame(metadata: any, wallClockMs: any, presentationTimeUs?: null): Promise<void>;
    commitAssemblyResult(result: any): Promise<void>;
    enqueueEncodingParts(parts?: any[]): Promise<void>;
    enqueueEncodingPart(part: any): Promise<void>;
    enqueueEncodedPart(part: any): Promise<void>;
    markIncomplete(reason: any): void;
    finalize(): Promise<any>;
    uploadManifest(parts: any, terminalStatus: any, settledPartsPromise?: Promise<any>): Promise<void>;
    /** @param {any[]} parts */
    settlePersistence(parts: any[]): void;
    markLateIncomplete(reason: any): void;
    sourceMetadata(): {
        pixelCount: number | null;
        aspectRatio: number | null;
        orientation: string | null;
    };
    configurationMetadata(): {
        output: any;
        roi: {
            smoothingTauMs: any;
            scale: any;
            verticalShiftRatio: any;
        };
        detector: {
            implementation: string;
            modelVersion: string;
            runtime: string;
            runtimeVersion: string;
            backend: string;
            minConfidence: any;
        };
        analysisWorkerCount: any;
        uploadDiagnostics: boolean;
        selectionPolicy: string;
        sampling: {
            method: string;
            roiDescriptorVersion: number;
            rounding: string;
            inputColorSpace: string;
            outputPixelFormat: string;
            frameSize: any;
        };
    };
    terminate(status: any, reason: any): any;
    terminalReason: any;
    /** @param {CaptureStatus} status @returns {Omit<import('./PublicTypes').StatusEvent,'type'|'reasonCode'|'reason'>} */
    metadata(status: CaptureStatus): Omit<import("./PublicTypes").StatusEvent, "type" | "reasonCode" | "reason">;
    setStatus(status: any, reason: any): void;
    closeWorker(): Promise<void>;
}
export type CaptureStatus = import("./PublicTypes").CaptureStatus;
export type Capability = import("./PublicTypes").Capability;
export type ManifestResult = import("./PublicTypes").ManifestResult;
/**
 * Options for the internal controller. Legacy JATOS identity fields remain
 * optional because public sessions use captureId/filenamePrefix instead.
 */
export type ControllerOptions = {
    video: HTMLVideoElement;
    studyResultId?: string | number | undefined;
    studyPage?: string | number | undefined;
    videoCounter?: string | number | undefined;
    captureId?: string | undefined;
    configuration: {
        faceRoiSmoothingTauMs: number;
        faceRoiScale: number;
        faceRoiVerticalShiftRatio: number;
        faceDetectionMinConfidence: number;
        analysisWorkerCount: 1 | 2;
        maxAttempts: number;
        retryDelayMs: number;
        diagnostics: boolean;
        output?: ReturnType<typeof resolveOutputSettings>;
    };
    uploadTracker?: {
        registerUpload: (id: string) => void;
        settleUpload: (id: string, status: import("./uploadState").UploadTrackerStatus) => void;
    } | undefined;
    uploadQueue?: any;
    uploadResultFile?: ((payload: Blob | string, filename: string) => unknown) | undefined;
    onStatus?: ((metadata: Omit<import("./PublicTypes").StatusEvent, "type" | "reasonCode">) => void) | undefined;
    onDiagnostic?: ((event: string, details?: any, severity?: string, source?: string) => void) | undefined;
    assetBaseUrl?: string | undefined;
    filenamePrefix?: string | undefined;
    context?: import("./PublicTypes").JsonObject | undefined;
    onArtifact?: ((event: import("./PublicTypes").ArtifactEvent) => void) | undefined;
    createPipelineWorker?: (() => PipelineWorker) | undefined;
};
import { FaceCropSink } from './FaceCropOutput';
import { resolveOutputSettings } from './OutputSettings';
