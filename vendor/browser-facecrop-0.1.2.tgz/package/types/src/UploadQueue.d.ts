/** @param {import('./PublicTypes').UploadQueueOptions} options @returns {import('./PublicTypes').UploadQueue} */
export function createUploadQueue({ transport }: import("./PublicTypes").UploadQueueOptions): import("./PublicTypes").UploadQueue;
/** @param {unknown} handle @returns {UploadQueue|null} */
export function resolveUploadQueue(handle: unknown): UploadQueue | null;
declare class UploadQueue {
    /** @param {import('./PublicTypes').Transport} transport */
    constructor(transport: import("./PublicTypes").Transport);
    transport: import("./PublicTypes").Transport;
    tail: Promise<void>;
    /** @type {Set<Promise<unknown>>} */
    pending: Set<Promise<unknown>>;
    /** @param {()=>PromiseLike<unknown>|unknown} task @param {()=>boolean} canEnqueue @param {Promise<void>} abortWait @param {()=>void} [onAdmitted] */
    enqueue(task: () => PromiseLike<unknown> | unknown, canEnqueue: () => boolean, abortWait: Promise<void>, onAdmitted?: () => void): Promise<{
        completion: Promise<unknown>;
    }>;
    /** @param {Promise<unknown>} completion */
    release(completion: Promise<unknown>): void;
}
export {};
