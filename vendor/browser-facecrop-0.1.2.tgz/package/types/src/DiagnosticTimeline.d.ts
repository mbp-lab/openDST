/** Internal opt-in timeline. One write at a time; later records share the next batch. */
export class DiagnosticTimeline {
    /** @param {{captureId:string,filenamePrefix:string,context:import('./PublicTypes').JsonObject,configuration:import('./PublicTypes').ResolvedConfiguration,assetBaseUrl:string,write:import('./PublicTypes').Transport['write'],onArtifact:(event:import('./PublicTypes').ArtifactEvent)=>void,uploadQueue?:any}} options */
    constructor({ captureId, filenamePrefix, context, configuration, assetBaseUrl, write, onArtifact, uploadQueue }: {
        captureId: string;
        filenamePrefix: string;
        context: import("./PublicTypes").JsonObject;
        configuration: import("./PublicTypes").ResolvedConfiguration;
        assetBaseUrl: string;
        write: import("./PublicTypes").Transport["write"];
        onArtifact: (event: import("./PublicTypes").ArtifactEvent) => void;
        uploadQueue?: any;
    });
    enabled: boolean;
    captureId: string;
    filenamePrefix: string;
    context: any;
    origin: number;
    sequence: number;
    batchIndex: number;
    droppedRecords: number;
    scheduledRecords: number;
    bufferBytes: number;
    /** @type {{record:any,size:number}[]} */
    buffer: {
        record: any;
        size: number;
    }[];
    /** @type {Promise<void>|null} */
    pending: Promise<void> | null;
    flushTimer: any;
    active: boolean;
    closed: boolean;
    abortSignal: Promise<any>;
    releaseAbort: (value: any) => void;
    onVisibility: () => void;
    onExit: () => void;
    sink: FaceCropSink;
    record(event: any, details?: {}, severity?: string, source?: string): void;
    scheduleFlush(): void;
    activate(): void;
    flush(): Promise<void> | null;
    drain(): Promise<void>;
    detach(): void;
    finish(): Promise<void>;
    abort(): void;
    snapshot(): {
        artifacts: any[];
        droppedRecords: number;
    };
}
import { FaceCropSink } from './FaceCropOutput';
