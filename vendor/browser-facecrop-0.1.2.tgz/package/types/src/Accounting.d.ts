/**
 * Reconcile the frame-count equations across submission, processing, assembly,
 * encoding, and persistence. This checks pipeline integrity only: a consistent
 * capture can contain held/default ROI frames or missed detections.
 * @internal
 * @param {Object} accounting Controller stage counters.
 * @param {number} acceptedFrames Number of assembled frames with an ROI.
 * @returns {{status:'consistent'|'inconsistent',checks:Object,callbackGapsInterpretation:string}}
 */
export function reconcileAccounting(accounting: any, acceptedFrames: number): {
    status: "consistent" | "inconsistent";
    checks: any;
    callbackGapsInterpretation: string;
};
