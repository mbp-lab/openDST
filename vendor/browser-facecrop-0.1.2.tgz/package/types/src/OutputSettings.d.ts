export function validateOutputResolution(resolution: any): any;
/** Exact size of this library's AVI headers, chunks, pixels, and frame index. */
export function rawAviSize(frameCount: any, resolution?: number): number;
/** RFC 1951 stored blocks (65,535 bytes each), plus RFC 1952's 18-byte wrapper. */
export function storedGzipSize(rawBytes: any): any;
/** @param {{resolution?:number,maxPartBytes?:number|null}} [settings] @returns {import('./PublicTypes').ResolvedOutputSettings} */
export function resolveOutputSettings({ resolution, maxPartBytes }?: {
    resolution?: number;
    maxPartBytes?: number | null;
}): import("./PublicTypes").ResolvedOutputSettings;
/** Legacy output defaults. Four-pixel alignment avoids BGR24 DIB row padding. */
export const DEFAULT_RESOLUTION: 72;
export const DEFAULT_MAX_PART_BYTES: number;
export const DEFAULT_RAW_PART_BYTES: number;
export const MAX_PART_BYTES: number;
export const AVI_HEADER_BYTES: 232;
