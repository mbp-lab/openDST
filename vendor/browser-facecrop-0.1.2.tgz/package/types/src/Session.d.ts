/**
 * Create a capture session around an application-owned video element and persistence transport.
 * Construction validates and snapshots the options; it does not create workers, prompt for
 * camera permission, persist data, or mutate globals. Call `prepare()` or `start()` explicitly.
 * The supplied context is cloned and must contain finite JSON values.
 *
 * @param {CaptureOptions} options Capture video, runtime asset URL, transport, and study context.
 * @returns {CaptureSession} Frozen lifecycle API for this capture.
 * @throws {TypeError|RangeError} If options, identifiers, URL, context, or configuration are invalid.
 */
export function createCaptureSession(options: CaptureOptions): CaptureSession;
export type CaptureStatus = import("./PublicTypes").CaptureStatus;
export type CaptureReasonCode = import("./PublicTypes").CaptureReasonCode;
export type CaptureOptions = import("./PublicTypes").CaptureOptions;
export type JsonObject = import("./PublicTypes").JsonObject;
export type JsonValue = import("./PublicTypes").JsonValue;
export type CaptureSession = import("./PublicTypes").CaptureSession;
export type CaptureResult = import("./PublicTypes").CaptureResult;
