/**
 * Build the serialized face-events sidecar. Input frames are retained as the
 * frame-level evidence array under `analysis.frames`; timestamps are integer
 * presentation microseconds, contiguous frame indexes restart at each part,
 * and precedingFramePresentationTimeUs carries continuity across part edges.
 * @internal
 * @param {{captureId?:string|null,context?:import('./PublicTypes').JsonObject,aviFilename?:string|null,segmentIndex?:number|null,partIndex?:number|null,frameCount?:number,precedingFramePresentationTimeUs?:number|null,source?:{width:number,height:number},selectionConfiguration?:{minDetectionConfidence:number,policy:string},frames?:import('./PublicTypes').FaceEventFrame[],output?:import('./PublicTypes').ResolvedOutputSettings}} [input]
 * @returns {import('./PublicTypes').FaceEvents}
 */
export function buildFaceEvents(input?: {
    captureId?: string | null;
    context?: import("./PublicTypes").JsonObject;
    aviFilename?: string | null;
    segmentIndex?: number | null;
    partIndex?: number | null;
    frameCount?: number;
    precedingFramePresentationTimeUs?: number | null;
    source?: {
        width: number;
        height: number;
    };
    selectionConfiguration?: {
        minDetectionConfidence: number;
        policy: string;
    };
    frames?: import("./PublicTypes").FaceEventFrame[];
    output?: import("./PublicTypes").ResolvedOutputSettings;
}): import("./PublicTypes").FaceEvents;
/**
 * Pure builder for the versioned capture manifest. It summarizes capture and
 * artifact outcomes while retaining source/capability/normalization and
 * accounting evidence; diagnostics are included only when explicitly enabled.
 * This internal builder assumes a valid captureId and terminal status; it does
 * not validate either value before serializing.
 * @internal
 * @param {{captureId:string,context?:import('./PublicTypes').JsonObject,filenamePrefix?:string|null,source?:import('./PublicTypes').SourceMetadata|null,sourceFailure?:import('./PublicTypes').SourceFailure|null,capability?:import('./PublicTypes').Capability|null,configuration?:import('./PublicTypes').ConfigurationMetadata|null,frameNormalization?:Record<string,unknown>|null,status:import('./PublicTypes').CaptureStatus,reason?:string|null,reasonCode?:import('./PublicTypes').CaptureReasonCode,statistics?:import('./PublicTypes').Statistics,parts?:ManifestPartInput[],diagnostics?:boolean}} input
 * @returns {import('./PublicTypes').CaptureManifest}
 */
export function buildCaptureManifest({ captureId, context, filenamePrefix, source, sourceFailure, capability, configuration, frameNormalization, status, reason, reasonCode, statistics, parts, diagnostics }?: {
    captureId: string;
    context?: import("./PublicTypes").JsonObject;
    filenamePrefix?: string | null;
    source?: import("./PublicTypes").SourceMetadata | null;
    sourceFailure?: import("./PublicTypes").SourceFailure | null;
    capability?: import("./PublicTypes").Capability | null;
    configuration?: import("./PublicTypes").ConfigurationMetadata | null;
    frameNormalization?: Record<string, unknown> | null;
    status: import("./PublicTypes").CaptureStatus;
    reason?: string | null;
    reasonCode?: import("./PublicTypes").CaptureReasonCode;
    statistics?: import("./PublicTypes").Statistics;
    parts?: ManifestPartInput[];
    diagnostics?: boolean;
}): import("./PublicTypes").CaptureManifest;
/** Public versioned capture summary schema. Bump only when its serialized contract changes. */
export const CAPTURE_MANIFEST_SCHEMA: "face-crop-manifest-v1";
/** Public per-part frame-evidence schema. Bump only when its serialized contract changes. */
export const FACE_EVENTS_SCHEMA: "face-crop-events-v3";
export type ManifestPartInput = {
    filename: string;
    faceEventsFilename: string;
    segmentIndex: number;
    partIndex: number;
    frameCount: number;
    frameRate?: number | null;
    byteLength?: number | null;
    width?: number;
    height?: number;
    status?: import("./PublicTypes").ArtifactStatus;
    avi?: {
        status: import("./PublicTypes").ArtifactStatus;
    };
    faceEvents?: {
        status: import("./PublicTypes").ArtifactStatus;
    };
};
