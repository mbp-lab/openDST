/** @internal @param {{minDetectionConfidence?:number,assetBaseUrl?:string}} [options] Optional absolute asset base URL overrides the configured worker root. */
export function createBlazeFaceDetector({ minDetectionConfidence, assetBaseUrl }?: {
    minDetectionConfidence?: number;
    assetBaseUrl?: string;
}): Promise<{
    tf: any;
    model: any;
}>;
export function convertBlazeFacePredictions(predictions: any, width: any, height: any): any;
export function validateFaceRoiDescriptor(roi: any): any;
/**
 * Area-average a square from tightly packed RGBA into one BGR24 output frame.
 * `rgbx` is borrowed for the duration of this call and an optional output view
 * is written in place; output row order is top-to-bottom.
 * @internal
 * @param {{rgbx:Uint8Array,width:number,height:number,roi:FaceRoiDescriptor,output?:Uint8Array,resolution?:number}} input
 * @returns {Uint8Array} resolution*resolution*3 bytes in B,G,R order
 */
export function processFaceCropFrame({ rgbx, width, height, roi, output, resolution }: {
    rgbx: Uint8Array;
    width: number;
    height: number;
    roi: FaceRoiDescriptor;
    output?: Uint8Array;
    resolution?: number;
}): Uint8Array;
/**
 * @typedef {'analysis'|'assembly'|'encoder'} PipelineRole Worker role selected
 * at initialization. A worker instance handles requests for one role.
 */
/**
 * @typedef {{role:PipelineRole,configuration:WorkerConfiguration,identity?:SegmenterIdentity}} InitializePayload
 */
/** @typedef {{frame:VideoFrame,width:number,height:number,timestampUs:number,wallClockMs:number,sequence:number}} ProcessFramePayload */
/** @typedef {{frame:VideoFrame,width:number,height:number}} WarmupPayload */
/**
 * Main-thread request envelope. Payload and transferable ownership depend on
 * request type; the RPC adapter serializes requests for each worker.
 * @typedef {{type:'initialize',payload:InitializePayload}|{type:'processFrame',payload:ProcessFramePayload}|{type:'processAnalysisResult',payload:AnalysisResult}|{type:'encodePart',payload:FaceCropPart}|{type:'warmup',payload:WarmupPayload}|{type:'finish'|'close',payload?:Object}} WorkerRequest
 */
/**
 * @typedef {{result?: unknown, error?: {name: string, message: string, stack: string|null}}} WorkerResponse
 * Worker reply to the single outstanding request.
 */
/**
 * @typedef {{coordinateSystem: 'face', transformType: 'dynamic-face-square', samplingVersion: 'area-average-v1', descriptorVersion: 2, x: number, y: number, size: number}} FaceRoiDescriptor
 * Integer source-pixel square consumed by the cropper. The descriptor version
 * and sampling name are persisted with output and therefore versioned data.
 */
/**
 * @typedef {{state: 'default'|'held'|'largest'|'reacquired', roi: FaceRoiDescriptor, candidateCount: number, selectedScore: number|null, selectedBoundingBox: {originX:number,originY:number,width:number,height:number}|null, tieBreakOccurred: boolean, detection:{rawCount:number,eligibleCount:number,scores:(number|null)[]}}} RoiSelection
 */
/**
 * @typedef {{captureId: string, segmentIndex: number, partIndex: number, filename: string, faceEventsFilename: string, frameCount: number, byteLength: number, resolution?:number,maxPartBytes?:number|null,maxFramesPerPart?:number,partSizePolicy?:string, bytes: Uint8Array, faceEvents: FaceCropPartEvidence}} FaceCropPart
 * Sealed frame batch; `bytes` contains frameCount consecutive resolution-square BGR24
 * frames and `faceEvents.frames` contains one matching provenance record each.
 */
/** @typedef {import('./PublicTypes').FaceEventFrame} FaceEventFrame */
/** @typedef {{schema:'face-crop-events-v3',captureId:string,context:import('./PublicTypes').JsonObject,aviFilename:string,segmentIndex:number,partIndex:number,frameCount:number,precedingFramePresentationTimeUs:number|null,output?:ReturnType<typeof resolveOutputSettings>,source:{width:number,height:number},selectionConfiguration:{minDetectionConfidence:number,policy:string},frames:FaceEventFrame[]}} FaceCropPartEvidence */
/** @typedef {{sequence:number,width:number,height:number,timestampUs:number,wallClockMs:number,detections:FaceDetection[],rgbx:Uint8Array,timings:{detectionMs:number,rgbaCopyMs:number,analysisMs:number}}} AnalysisResult */
/** @typedef {{boundingBox:{originX:number,originY:number,width:number,height:number},categories:{score:number}[]}} FaceDetection */
/** @typedef {{detectionMs:number,rgbaCopyMs:number,analysisMs:number,roiSelectionMs:number,cropAndSegmentMs:number,assemblyMs:number}} AssemblyTimings */
/** @typedef {{sequence:number,accepted:boolean,detectionState:RoiSelection['state'],parts:FaceCropPart[],timings:AssemblyTimings}} AssemblyCommit */
/** @typedef {{commits:AssemblyCommit[],bufferedResultCount:number}} ProcessAnalysisResponse */
/** @typedef {{commits:[],parts:FaceCropPart[],bufferedResultCount:0,timings:{assemblyMs:number}}} FinishResponse */
/** @typedef {{artifact:import('./FaceCropOutput').EncodedPatchArtifact,timings:{encodingMs:number}}} EncodingResponse */
/** @typedef {{}} WarmupResponse */
/** @typedef {{mode:'nv12-bt709-full'|'nv12-bt709-limited'|'rgba-copy',nativeFormat:string|null,nativeWidth:number,nativeHeight:number,presentedWidth:number,presentedHeight:number,rotation:0|90|180|270,flip:boolean,colorSpace:Record<string,unknown>|null,layouts:{offset:number,stride:number}[],nativeAllocationSize:number,method?:string,clockwiseDistance?:number|null,counterclockwiseDistance?:number|null}} FrameNormalization */
/** @typedef {{faceRoiSmoothingTauMs:number,faceRoiScale:number,faceRoiVerticalShiftRatio:number,faceDetectionMinConfidence:number,analysisWorkerCount:number,assetBaseUrl:string,diagnostics:boolean,output?:ReturnType<typeof resolveOutputSettings>,frameNormalization?:FrameNormalization|null}} WorkerConfiguration */
/** @typedef {{filenamePrefix?:string|null,context:import('./PublicTypes').JsonObject,studyResultId?:string|number,studyPage?:string|number,videoCounter?:string|number,captureId:string}} SegmenterIdentity */
/** @internal Persisted patch width and height in pixels. */
export const PATCH_SIZE: 72;
export const BGR24_FRAME_BYTES: number;
export const MAX_FRAMES_PER_PART: 539;
export namespace FACE_ROI_DESCRIPTOR {
    let coordinateSystem: string;
    let transformType: string;
    let samplingVersion: string;
    let descriptorVersion: number;
}
export const FACE_COORDINATE_SYSTEM: "face";
export const DYNAMIC_FACE_SQUARE: "dynamic-face-square";
export const AREA_AVERAGE_V1: "area-average-v1";
export const FACE_ROI_DESCRIPTOR_VERSION: 2;
/**
 * Selects one deterministic face square per frame and smooths its geometry.
 * Misses hold a still-valid prior square; before the first usable detection the
 * provider emits a centered default square. Selection state feeds persisted
 * frame provenance and is reset per capture.
 * @internal
 */
export class FaceRoiProvider {
    constructor({ scale, verticalShiftRatio, smoothingTauMs, minDetectionConfidence }?: {
        scale?: number | undefined;
        verticalShiftRatio?: number | undefined;
        smoothingTauMs?: number | undefined;
        minDetectionConfidence?: number | undefined;
    });
    configuration: {
        scale: number;
        verticalShiftRatio: number;
        smoothingTauMs: number;
        minDetectionConfidence: number;
    };
    previous: any;
    previousFrameTimestampMs: number | null;
    hasDetection: boolean;
    hadMiss: boolean;
    defaultRoi(width: any, height: any): any;
    /** @param {{width:number,height:number,detections:FaceDetection[],timestampMs:number}} input @returns {RoiSelection} */
    getSelection({ width, height, detections, timestampMs }: {
        width: number;
        height: number;
        detections: FaceDetection[];
        timestampMs: number;
    }): RoiSelection;
    getRoi(input: any): FaceRoiDescriptor;
}
export class FaceCropProcessor {
    process(input: any): Uint8Array<ArrayBufferLike>;
}
/**
 * Accumulates ordered frames into bounded parts. A source geometry change seals
 * the current part and starts a new segment; frame-count limits also seal a
 * part. Presentation timestamps remain strictly increasing across part edges.
 * @internal
 */
export class FaceCropSegmenter {
    constructor({ filenamePrefix, context, studyResultId, studyPage, videoCounter, captureId, resolution, maxPartBytes, maxFramesPerPart, selectionConfiguration }: {
        filenamePrefix: any;
        context?: {} | undefined;
        studyResultId: any;
        studyPage: any;
        videoCounter: any;
        captureId: any;
        resolution?: number | undefined;
        maxPartBytes?: null | undefined;
        maxFramesPerPart: any;
        selectionConfiguration?: {} | undefined;
    });
    output: import("./PublicTypes").ResolvedOutputSettings;
    identity: {
        filenamePrefix: any;
        context: {};
        studyResultId: any;
        studyPage: any;
        videoCounter: any;
        captureId: any;
    };
    maxFrames: any;
    selectionConfiguration: {};
    sourceDimensions: {
        width: any;
        height: any;
    } | null;
    segmentIndex: number;
    partIndex: number;
    part: {
        bytes: Uint8Array<ArrayBuffer>;
        frameCount: number;
        events: never[];
        precedingFramePresentationTimeUs: any;
    } | null;
    previousPresentationTimeUs: any;
    appendFrame({ bgr24, writeBgr24, sourceWidth, sourceHeight, roi, provenance, timestampUs, wallClockMs }: {
        bgr24: any;
        writeBgr24: any;
        sourceWidth: any;
        sourceHeight: any;
        roi: any;
        provenance: any;
        timestampUs: any;
        wallClockMs: any;
    }): ({
        captureId: any;
        segmentIndex: number;
        partIndex: number;
        filename: string;
        resolution: number;
        maxPartBytes: number | null;
        maxFramesPerPart: any;
        partSizePolicy: import("./PublicTypes").PartSizePolicy;
        faceEventsFilename: string;
        frameCount: number;
        byteLength: number;
        bytes: Uint8Array<ArrayBuffer>;
        faceEvents: {
            schema: string;
            captureId: any;
            context: {};
            aviFilename: string;
            segmentIndex: number;
            partIndex: number;
            frameCount: number;
            precedingFramePresentationTimeUs: any;
            output: {
                resolution: number;
                width: number;
                height: number;
                frameBytes: number;
                maxPartBytes: number | null;
                maxFramesPerPart: number;
                policy: import("./PublicTypes").PartSizePolicy;
                format: import("./PublicTypes").OutputFormat;
            };
            source: {
                width?: any;
                height?: any;
            };
            selectionConfiguration: {};
            frames: never[];
        };
    } | null)[];
    finish(): {
        captureId: any;
        segmentIndex: number;
        partIndex: number;
        filename: string;
        resolution: number;
        maxPartBytes: number | null;
        maxFramesPerPart: any;
        partSizePolicy: import("./PublicTypes").PartSizePolicy;
        faceEventsFilename: string;
        frameCount: number;
        byteLength: number;
        bytes: Uint8Array<ArrayBuffer>;
        faceEvents: {
            schema: string;
            captureId: any;
            context: {};
            aviFilename: string;
            segmentIndex: number;
            partIndex: number;
            frameCount: number;
            precedingFramePresentationTimeUs: any;
            output: {
                resolution: number;
                width: number;
                height: number;
                frameBytes: number;
                maxPartBytes: number | null;
                maxFramesPerPart: number;
                policy: import("./PublicTypes").PartSizePolicy;
                format: import("./PublicTypes").OutputFormat;
            };
            source: {
                width?: any;
                height?: any;
            };
            selectionConfiguration: {};
            frames: never[];
        };
    }[];
    seal(): {
        captureId: any;
        segmentIndex: number;
        partIndex: number;
        filename: string;
        resolution: number;
        maxPartBytes: number | null;
        maxFramesPerPart: any;
        partSizePolicy: import("./PublicTypes").PartSizePolicy;
        faceEventsFilename: string;
        frameCount: number;
        byteLength: number;
        bytes: Uint8Array<ArrayBuffer>;
        faceEvents: {
            schema: string;
            captureId: any;
            context: {};
            aviFilename: string;
            segmentIndex: number;
            partIndex: number;
            frameCount: number;
            precedingFramePresentationTimeUs: any;
            output: {
                resolution: number;
                width: number;
                height: number;
                frameBytes: number;
                maxPartBytes: number | null;
                maxFramesPerPart: number;
                policy: import("./PublicTypes").PartSizePolicy;
                format: import("./PublicTypes").OutputFormat;
            };
            source: {
                width?: any;
                height?: any;
            };
            selectionConfiguration: {};
            frames: never[];
        };
    } | null;
}
/** @internal Normalizes and analyzes frames; always closes transferred VideoFrames. */
export class FaceCropAnalysisPipeline {
    initialize({ configuration }: {
        configuration: any;
    }): Promise<void>;
    normalization: any;
    detector: {
        tf: any;
        model: any;
    } | null | undefined;
    /** @param {ProcessFramePayload} input @returns {Promise<AnalysisResult>} */
    processFrame({ frame, width, height, timestampUs, wallClockMs, sequence }: ProcessFramePayload): Promise<AnalysisResult>;
    /** @param {WarmupPayload} input @returns {Promise<WarmupResponse>} */
    warmup({ frame, width, height }: WarmupPayload): Promise<WarmupResponse>;
    close(): void;
}
/** @internal Reorders parallel analysis results and commits them by sequence. */
export class FaceCropAssemblyPipeline {
    pending: Map<any, any>;
    nextSequence: number;
    initialize({ configuration, identity }: {
        configuration: any;
        identity: any;
    }): Promise<void>;
    maxPendingResults: any;
    roi: FaceRoiProvider | null | undefined;
    output: any;
    segmenter: FaceCropSegmenter | null | undefined;
    /** @param {AnalysisResult} result @returns {Promise<ProcessAnalysisResponse>} */
    processAnalysisResult(result: AnalysisResult): Promise<ProcessAnalysisResponse>;
    /** @returns {Promise<FinishResponse>} */
    finish(): Promise<FinishResponse>;
    close(): void;
}
/** @internal Encodes sealed parts on the worker side before transfer to the sink. */
export class FaceCropEncodingPipeline {
    constructor({ encodePart }?: {
        encodePart?: typeof encodePatchArtifact | undefined;
    });
    encodePart: typeof encodePatchArtifact;
    initialize(): Promise<void>;
    /** @param {FaceCropPart} part @returns {Promise<EncodingResponse>} */
    encode(part: FaceCropPart): Promise<EncodingResponse>;
    close(): void;
}
/**
 * Worker role selected
 * at initialization. A worker instance handles requests for one role.
 */
export type PipelineRole = "analysis" | "assembly" | "encoder";
export type InitializePayload = {
    role: PipelineRole;
    configuration: WorkerConfiguration;
    identity?: SegmenterIdentity;
};
export type ProcessFramePayload = {
    frame: VideoFrame;
    width: number;
    height: number;
    timestampUs: number;
    wallClockMs: number;
    sequence: number;
};
export type WarmupPayload = {
    frame: VideoFrame;
    width: number;
    height: number;
};
/**
 * Main-thread request envelope. Payload and transferable ownership depend on
 * request type; the RPC adapter serializes requests for each worker.
 */
export type WorkerRequest = {
    type: "initialize";
    payload: InitializePayload;
} | {
    type: "processFrame";
    payload: ProcessFramePayload;
} | {
    type: "processAnalysisResult";
    payload: AnalysisResult;
} | {
    type: "encodePart";
    payload: FaceCropPart;
} | {
    type: "warmup";
    payload: WarmupPayload;
} | {
    type: "finish" | "close";
    payload?: any;
};
/**
 * Worker reply to the single outstanding request.
 */
export type WorkerResponse = {
    result?: unknown;
    error?: {
        name: string;
        message: string;
        stack: string | null;
    };
};
/**
 * Integer source-pixel square consumed by the cropper. The descriptor version
 * and sampling name are persisted with output and therefore versioned data.
 */
export type FaceRoiDescriptor = {
    coordinateSystem: "face";
    transformType: "dynamic-face-square";
    samplingVersion: "area-average-v1";
    descriptorVersion: 2;
    x: number;
    y: number;
    size: number;
};
export type RoiSelection = {
    state: "default" | "held" | "largest" | "reacquired";
    roi: FaceRoiDescriptor;
    candidateCount: number;
    selectedScore: number | null;
    selectedBoundingBox: {
        originX: number;
        originY: number;
        width: number;
        height: number;
    } | null;
    tieBreakOccurred: boolean;
    detection: {
        rawCount: number;
        eligibleCount: number;
        scores: (number | null)[];
    };
};
/**
 * Sealed frame batch; `bytes` contains frameCount consecutive resolution-square BGR24
 * frames and `faceEvents.frames` contains one matching provenance record each.
 */
export type FaceCropPart = {
    captureId: string;
    segmentIndex: number;
    partIndex: number;
    filename: string;
    faceEventsFilename: string;
    frameCount: number;
    byteLength: number;
    resolution?: number;
    maxPartBytes?: number | null;
    maxFramesPerPart?: number;
    partSizePolicy?: string;
    bytes: Uint8Array;
    faceEvents: FaceCropPartEvidence;
};
export type FaceEventFrame = import("./PublicTypes").FaceEventFrame;
export type FaceCropPartEvidence = {
    schema: "face-crop-events-v3";
    captureId: string;
    context: import("./PublicTypes").JsonObject;
    aviFilename: string;
    segmentIndex: number;
    partIndex: number;
    frameCount: number;
    precedingFramePresentationTimeUs: number | null;
    output?: ReturnType<typeof resolveOutputSettings>;
    source: {
        width: number;
        height: number;
    };
    selectionConfiguration: {
        minDetectionConfidence: number;
        policy: string;
    };
    frames: FaceEventFrame[];
};
export type AnalysisResult = {
    sequence: number;
    width: number;
    height: number;
    timestampUs: number;
    wallClockMs: number;
    detections: FaceDetection[];
    rgbx: Uint8Array;
    timings: {
        detectionMs: number;
        rgbaCopyMs: number;
        analysisMs: number;
    };
};
export type FaceDetection = {
    boundingBox: {
        originX: number;
        originY: number;
        width: number;
        height: number;
    };
    categories: {
        score: number;
    }[];
};
export type AssemblyTimings = {
    detectionMs: number;
    rgbaCopyMs: number;
    analysisMs: number;
    roiSelectionMs: number;
    cropAndSegmentMs: number;
    assemblyMs: number;
};
export type AssemblyCommit = {
    sequence: number;
    accepted: boolean;
    detectionState: RoiSelection["state"];
    parts: FaceCropPart[];
    timings: AssemblyTimings;
};
export type ProcessAnalysisResponse = {
    commits: AssemblyCommit[];
    bufferedResultCount: number;
};
export type FinishResponse = {
    commits: [];
    parts: FaceCropPart[];
    bufferedResultCount: 0;
    timings: {
        assemblyMs: number;
    };
};
export type EncodingResponse = {
    artifact: import("./FaceCropOutput").EncodedPatchArtifact;
    timings: {
        encodingMs: number;
    };
};
export type WarmupResponse = {};
export type FrameNormalization = {
    mode: "nv12-bt709-full" | "nv12-bt709-limited" | "rgba-copy";
    nativeFormat: string | null;
    nativeWidth: number;
    nativeHeight: number;
    presentedWidth: number;
    presentedHeight: number;
    rotation: 0 | 90 | 180 | 270;
    flip: boolean;
    colorSpace: Record<string, unknown> | null;
    layouts: {
        offset: number;
        stride: number;
    }[];
    nativeAllocationSize: number;
    method?: string;
    clockwiseDistance?: number | null;
    counterclockwiseDistance?: number | null;
};
export type WorkerConfiguration = {
    faceRoiSmoothingTauMs: number;
    faceRoiScale: number;
    faceRoiVerticalShiftRatio: number;
    faceDetectionMinConfidence: number;
    analysisWorkerCount: number;
    assetBaseUrl: string;
    diagnostics: boolean;
    output?: ReturnType<typeof resolveOutputSettings>;
    frameNormalization?: FrameNormalization | null;
};
export type SegmenterIdentity = {
    filenamePrefix?: string | null;
    context: import("./PublicTypes").JsonObject;
    studyResultId?: string | number;
    studyPage?: string | number;
    videoCounter?: string | number;
    captureId: string;
};
import { encodePatchArtifact } from './FaceCropOutput';
import { resolveOutputSettings } from './OutputSettings';
