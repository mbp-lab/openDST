/**
 * A JSON-compatible value. Numbers must be finite; objects must be plain JSON objects.
 */
export type JsonValue = string | number | boolean | null | JsonObject | JsonValue[];
/**
 * Study-defined JSON metadata. The library validates and copies this object at creation.
 */
export type JsonObject = {
    [key: string]: JsonValue;
};
/**
 * Public result status. New sessions report `disabled`; successful preparation reports `ready`.
 */
export type CaptureStatus = "disabled" | "ready" | "unsupported" | "capturing" | "complete" | "incomplete" | "aborted";
/**
 * Stable high-level failure classification; source-specific failures use `failureCode`.
 */
export type CaptureReasonCode = "CAPABILITY_UNSUPPORTED" | "CAPTURE_INCOMPLETE" | "CAPTURE_ABORTED";
/**
 * Artifact persistence status. `uncertain` means the write outcome cannot be concluded;
 * it does not prove that stored data was deleted.
 */
export type ArtifactStatus = "pending" | "succeeded" | "uncertain" | "failed" | "discarded" | "not_attempted";
/**
 * Serializable observer or probe exception details.
 */
export type ErrorMetadata = {
    name: string;
    message: string;
};
/**
 * Optional configuration overrides. Unknown fields and coercible strings are rejected.
 */
export type CaptureConfiguration = {
    roi?: RoiConfiguration | undefined;
    detector?: DetectorConfiguration | undefined;
    pipeline?: PipelineConfiguration | undefined;
    persistence?: PersistenceConfiguration | undefined;
    output?: OutputConfiguration | undefined;
    uploadDiagnostics?: boolean | undefined;
};
/**
 * ROI smoothing is in milliseconds; vertical shift is a ratio of crop size.
 */
export type RoiConfiguration = {
    smoothingTauMs?: number;
    scale?: number;
    verticalShiftRatio?: number;
};
/**
 * Minimum face detector confidence, from 0 through 1.
 */
export type DetectorConfiguration = {
    minConfidence?: number;
};
/**
 * Number of concurrent analysis workers; currently one or two.
 */
export type PipelineConfiguration = {
    analysisWorkerCount?: 1 | 2;
};
/**
 * Persistence retry settings; the retry delay is multiplied by the attempt number.
 */
export type PersistenceConfiguration = {
    maxAttempts?: number;
    retryDelayMs?: number;
};
/**
 * Square crop pixels and optional strict uploaded gzip size in MiB (fractional values allowed).
 */
export type OutputConfiguration = {
    resolution?: number;
    maxPartMiB?: number | null;
};
/**
 * Resolved square crop output settings.
 */
export type ResolvedOutputConfiguration = Readonly<{
    resolution: number;
    maxPartMiB: number | null;
}>;
/**
 * Encoded pixel geometry identifier; v1 remains exactly 72 square.
 */
export type OutputFormat = "patch-video-avi-gzip-bgr24-v1" | "patch-video-avi-gzip-bgr24-v2";
/**
 * Part splitting behavior.
 */
export type PartSizePolicy = "legacy-raw-frame-budget-v1" | "stored-gzip-ceiling-v1";
/**
 * Reported optional byte ceiling and effective frame cap.
 */
export type PartSizeMetadata = {
    maxPartBytes: number | null;
    maxFramesPerPart: number;
    policy: PartSizePolicy;
};
/**
 * Applied output settings used by the pipeline.
 */
export type ResolvedOutputSettings = {
    resolution: number;
    width: number;
    height: number;
    frameBytes: number;
    maxPartBytes: number | null;
    maxFramesPerPart: number;
    policy: PartSizePolicy;
    format: OutputFormat;
};
/**
 * One immutable, fully resolved ROI configuration.
 */
export type ResolvedRoiConfiguration = Readonly<{
    smoothingTauMs: number;
    scale: number;
    verticalShiftRatio: number;
}>;
/**
 * One immutable, fully resolved detector configuration.
 */
export type ResolvedDetectorConfiguration = Readonly<{
    minConfidence: number;
}>;
/**
 * One immutable, fully resolved pipeline configuration.
 */
export type ResolvedPipelineConfiguration = Readonly<{
    analysisWorkerCount: 1 | 2;
}>;
/**
 * One immutable, fully resolved persistence configuration.
 */
export type ResolvedPersistenceConfiguration = Readonly<{
    maxAttempts: number;
    retryDelayMs: number;
}>;
/**
 * Fully resolved configuration, frozen along with each settings group.
 */
export type ConfigurationValues = {
    /**
     * Smoothing 0–10000 ms (default 100), scale 1–3 (1.4), vertical shift -1–1 (0.15).
     */
    roi: ResolvedRoiConfiguration;
    /**
     * Confidence 0–1 (default 0.5).
     */
    detector: ResolvedDetectorConfiguration;
    /**
     * Worker count: one or two (default two).
     */
    pipeline: ResolvedPipelineConfiguration;
    /**
     * Resolution default 72 pixels; maxPartMiB defaults to 4 MiB, and null preserves the legacy raw-frame budget.
     */
    output: ResolvedOutputConfiguration;
    /**
     * Attempts 1–10 (default 3); retry delay 0–60000 ms (default 100), multiplied by attempt number.
     */
    persistence: ResolvedPersistenceConfiguration;
    /**
     * Console diagnostics and timeline persistence, false by default.
     */
    uploadDiagnostics: boolean;
};
/**
 * Fully resolved immutable settings.
 */
export type ResolvedConfiguration = Readonly<ConfigurationValues>;
/**
 * An AVI payload is a gzip Blob; sidecars and manifests are JSON strings.
 */
export type ArtifactWrite = {
    filename: string;
    payload: Blob | string;
};
/**
 * Caller-owned persistence adapter. Resolve only once storage acknowledges persistence.
 * Rejection may occur after storage accepted a write; retries/abort cannot prove deletion.
 */
export type Transport = {
    write: (artifact: ArtifactWrite) => PromiseLike<unknown>;
};
/**
 * Opaque in-memory scheduler created by createUploadQueue and shared across capture sessions.
 */
export type UploadQueue = object;
/**
 * Options for creating an in-memory study-scoped upload scheduler.
 */
export type UploadQueueOptions = {
    transport: Transport;
};
/**
 * Explicit JATOS API; a synchronous upload implementation is also promise-wrapped.
 */
export type JatosApi = {
    uploadResultFile: (payload: Blob | string, filename: string) => unknown;
};
/**
 * Session creation inputs. No permissions, workers, or writes are triggered by construction.
 */
export type CaptureOptions = {
    /**
     * Playing, application-owned video; `prepare()` waits for a presented frame.
     */
    video: HTMLVideoElement;
    /**
     * Explicit persistence implementation; required unless uploadQueue is supplied.
     */
    transport?: Transport | undefined;
    /**
     * Optional study-scoped queue shared by multiple capture sessions.
     */
    uploadQueue?: UploadQueue;
    /**
     * Absolute HTTP(S) directory URL without query/fragment; trailing slash normalized.
     */
    assetBaseUrl: string;
    /**
     * Missing settings use validated defaults.
     */
    config?: CaptureConfiguration | undefined;
    /**
     * Globally unique recording ID, letters/digits/underscore/hyphen; generated if omitted.
     */
    captureId?: string | undefined;
    /**
     * Optional filename token with the same characters, or empty string.
     */
    filenamePrefix?: string | undefined;
    /**
     * Plain JSON metadata; copied on creation and in getResult().
     */
    context?: JsonObject | undefined;
    /**
     * Observer exceptions are captured in observerErrors.
     */
    onEvent?: ((event: CaptureEvent) => void) | undefined;
};
/**
 * File status snapshot without internal promises or event-only upload IDs.
 */
export type ArtifactResult = {
    /**
     * Path submitted to the persistence transport.
     */
    filename: string;
    /**
     * Latest known persistence state.
     */
    status: ArtifactStatus;
    /**
     * Number of write attempts observed; zero before a write starts.
     */
    attempts: number;
};
/**
 * Stable upload identity shared by progress and lifecycle events.
 */
export type ArtifactEventIdentity = {
    captureId?: string | null;
    uploadId: string;
};
/**
 * Artifact events report persistence progress; `captureId` is null for manifest writes.
 * Pending events may repeat during retries. Use the registered/settled events for host tracking.
 */
export type ArtifactEvent = {
    type: "artifact";
    artifact: ArtifactResult & ArtifactEventIdentity;
};
/**
 * Emitted once per upload ID before its first progress notification, including artifacts
 * skipped without a write. Registration does not imply storage was attempted.
 */
export type ArtifactRegisteredEvent = {
    type: "artifact_registered";
    artifact: ArtifactResult & ArtifactEventIdentity;
};
/**
 * Emitted once per upload ID after its first terminal progress notification. Settlement
 * is an outcome, not necessarily success or proof of remote deletion; it may arrive after abort.
 */
export type ArtifactSettledEvent = {
    type: "artifact_settled";
    artifact: ArtifactResult & ArtifactEventIdentity & {
        status: Exclude<ArtifactStatus, "pending">;
    };
};
/**
 * Manifest write outcome, separate from the serialized manifest contents.
 */
export type ManifestResult = {
    filename: string;
    status: ArtifactStatus;
};
/**
 * Source dimension or video track failure categories emitted by the capture controller.
 */
export type SourceFailureCode = "VIDEO_TRACK_ENDED" | "VIDEO_STREAM_INACTIVE" | "VIDEO_DIMENSIONS_UNAVAILABLE" | "VIDEO_DIMENSIONS_UNSUPPORTED";
/**
 * Dimensions observed from the presented video at the time of a source failure.
 */
export type ObservedVideoDimensions = {
    width: number | null;
    height: number | null;
    readyState: number | null;
};
/**
 * Track states observed from the application-owned stream.
 */
export type ObservedTrackState = {
    streamActive: boolean | null;
    videoTrackReadyStates: (string | null)[];
};
/**
 * Most recent supported frame dimensions, when one was observed.
 */
export type LastValidDimensions = {
    width: number;
    height: number;
};
/**
 * Source failure recorded when the video dimensions or stream become unusable.
 * `observed` contains current source and track state; prior valid dimensions may be absent.
 */
export type SourceFailure = {
    /**
     * Stable source failure category.
     */
    code: SourceFailureCode;
    /**
     * Human-readable explanation.
     */
    reason: string;
    /**
     * Current source and track observations.
     */
    observed: ObservedVideoDimensions & ObservedTrackState;
    /**
     * Last dimensions accepted by the pipeline.
     */
    lastValidDimensions: LastValidDimensions | null;
};
/**
 * Probe result; check contents vary by browser and the stage that failed.
 */
export type Capability = {
    status: "not-run" | "passed" | "failed";
    failedStage?: string | null;
    error?: ErrorMetadata | null;
    checks?: Record<string, unknown>;
};
/**
 * Aggregated duration in milliseconds; values are null until observations arrive.
 */
export type TimingMetric = {
    count: number;
    meanMs: number | null;
    minMs: number | null;
    maxMs: number | null;
};
/**
 * Detector warmup frame counts and elapsed time in milliseconds.
 */
export type DetectorWarmup = {
    requested: number;
    completed: number;
    totalMs: number;
    meanMs: number | null;
};
/**
 * Accounting summary verification; callback gaps do not establish a single cause.
 */
export type AccountingReconciliation = {
    status: "consistent" | "inconsistent";
    checks: Record<string, boolean>;
    callbackGapsInterpretation: string;
};
/**
 * Pipeline counts and queue waits. Browser callback gaps do not identify a single cause.
 */
export type CaptureAccounting = {
    submittedFrames: number;
    processedFrames: number;
    sealedFrames: number;
    encodedFrames: number;
    persistedFrames: number;
    failedPersistenceFrames: number;
    failedProcessingFrames: number;
    failedEncodingFrames: number;
    discardedFrames: number;
    callbackGaps: number;
    analysisQueueWaitMs: number;
    encodingQueueWaitMs: number;
    /**
     * Available after finalization.
     */
    reconciliation?: AccountingReconciliation | undefined;
};
/**
 * Capture health metrics, with duration fields in milliseconds.
 */
export type Statistics = {
    accounting: CaptureAccounting;
    faceDetections: number;
    faceDetectionMisses: number;
    acceptedFrames: number;
    skippedFrames: number;
    frameCallbacks: number;
    frameTimings: Record<string, TimingMetric>;
    encodingTimings: Record<string, TimingMetric>;
    detectorWarmup: DetectorWarmup;
};
/**
 * Source dimensions and orientation summary. Values may be null before a usable frame exists.
 */
export type SourceMetadata = {
    /**
     * Presented source width in pixels.
     */
    width?: number | null | undefined;
    /**
     * Presented source height in pixels.
     */
    height?: number | null | undefined;
    /**
     * HTML media ready state.
     */
    readyState?: number | null | undefined;
    /**
     * Presented width multiplied by height.
     */
    pixelCount?: number | null | undefined;
    /**
     * Presented width divided by height.
     */
    aspectRatio?: number | null | undefined;
    /**
     * Shape of the presented frame.
     */
    orientation?: "square" | "landscape" | "portrait" | null | undefined;
};
/**
 * ROI settings recorded as applied algorithm provenance.
 */
export type RoiConfigurationMetadata = {
    smoothingTauMs: number;
    scale: number;
    verticalShiftRatio: number;
};
/**
 * Detector implementation and runtime versions recorded in output metadata.
 */
export type DetectorConfigurationMetadata = {
    implementation: string;
    modelVersion: string;
    runtime: string;
    runtimeVersion: string;
    backend: string;
    minConfidence: number;
};
/**
 * Sampling method and crop descriptor version recorded in output metadata.
 */
export type SamplingConfigurationMetadata = {
    method: string;
    roiDescriptorVersion: number;
    rounding: string;
    inputColorSpace: string;
    outputPixelFormat: string;
    frameSize: number;
};
/**
 * Algorithm provenance applied to the recording, distinct from user configuration overrides.
 */
export type ConfigurationMetadata = {
    output: ResolvedOutputSettings;
    roi: RoiConfigurationMetadata;
    detector: DetectorConfigurationMetadata;
    uploadDiagnostics: boolean;
    analysisWorkerCount: number;
    selectionPolicy: string;
    sampling: SamplingConfigurationMetadata;
};
/**
 * Byte offset and row stride for a copied image plane.
 */
export type FramePlaneLayout = {
    offset: number;
    stride: number;
};
/**
 * Browser color-space attributes observed during frame preflight; fields vary by browser.
 */
export type FrameColorSpaceMetadata = Record<string, unknown> | null;
/**
 * Frame normalization selected during startup preflight and reused for the capture.
 * It records one initial decision, not orientation changes on each frame.
 */
export type FrameNormalizationMetadata = {
    /**
     * Pixel conversion path, including the NV12 range scaling applied.
     */
    mode: "nv12-bt709-full" | "nv12-bt709-limited" | "rgba-copy";
    /**
     * Browser-reported source pixel format, when available.
     */
    nativeFormat: string | null;
    /**
     * Native VideoFrame width in pixels.
     */
    nativeWidth: number;
    /**
     * Native VideoFrame height in pixels.
     */
    nativeHeight: number;
    /**
     * Presented video width in pixels.
     */
    presentedWidth: number;
    /**
     * Presented video height in pixels.
     */
    presentedHeight: number;
    /**
     * Clockwise normalization rotation, in degrees.
     */
    rotation: 0 | 90 | 180 | 270;
    /**
     * Whether the copied frame was flipped.
     */
    flip: boolean;
    /**
     * Browser color-space attributes used by preflight.
     */
    colorSpace: FrameColorSpaceMetadata;
    /**
     * Plane offsets and strides in bytes.
     */
    layouts: FramePlaneLayout[];
    /**
     * Native frame allocation size in bytes.
     */
    nativeAllocationSize: number;
    /**
     * Orientation selection method identifier.
     */
    method: string;
    /**
     * Optional luminance comparison distance.
     */
    clockwiseDistance: number | null;
    /**
     * Optional luminance comparison distance.
     */
    counterclockwiseDistance: number | null;
};
/**
 * Pixel extraction API and normalized output format.
 */
export type OutputExtractionMetadata = {
    api: "VideoFrame.copyTo";
    normalizationMode: string | null;
    nativeFormat: string | null;
    outputFormat: "RGBA";
};
/**
 * Encoded artifact format and frame extraction contract.
 */
export type OutputMetadata = {
    format: OutputFormat;
    container: "avi.gz";
    transportEncoding: "gzip";
    videoCodec: "DIB";
    pixelFormat: "bgr24";
    /**
     * Per-part frame rate is derived from presentation timestamps.
     */
    aviHeaderFrameRatePolicy: string;
    /**
     * Output frame width and height, in pixels.
     */
    frameSize: number;
    width: number;
    height: number;
    partSize: PartSizeMetadata;
    extraction: OutputExtractionMetadata;
};
/**
 * Controller status notification. Its status is not the getResult() ready projection;
 * preparation readiness should be read from the returned session result.
 */
export type StatusEvent = {
    type: "status";
    status: Exclude<CaptureStatus, "ready">;
    reasonCode: CaptureReasonCode | null;
    reason: string | null;
    failureCode: SourceFailureCode | null;
    sourceFailure: SourceFailure | null;
    capability: Capability;
    capture: {
        captureId: string;
        context: JsonObject;
    };
    source: SourceMetadata;
    manifest: ManifestResult | null;
    configuration: ConfigurationMetadata;
    output: OutputMetadata;
    statistics: Statistics;
};
/**
 * Narrow with event.type before reading artifact or status fields.
 */
export type CaptureEvent = StatusEvent | ArtifactEvent | ArtifactRegisteredEvent | ArtifactSettledEvent;
/**
 * Structured lifecycle outcome. Runtime pipeline failures resolve a result, rather
 * than generally rejecting. Inspect status and persistence outcomes before navigating.
 * Artifact arrays and context are copied; statistics, capability, sourceFailure,
 * and the manifest upload outcome can share mutable references with the session.
 */
export type CaptureResult = {
    status: CaptureStatus;
    reasonCode: CaptureReasonCode | null;
    reason: string | null;
    failureCode: SourceFailureCode | null;
    sourceFailure: SourceFailure | null;
    capture: {
        captureId: string;
        context: JsonObject;
    };
    statistics: Statistics;
    /**
     * Full probe checks are included only when uploadDiagnostics is enabled.
     */
    capability: Capability;
    /**
     * Applied resolution and part-size behavior.
     */
    output: OutputMetadata;
    artifacts: ArtifactResult[];
    manifest: ManifestResult | null;
    diagnosticUploads: {
        artifacts: ArtifactResult[];
        droppedRecords: number;
    };
    observerErrors: ErrorMetadata[];
};
/**
 * One frozen capture handle. Each operation reuses its promise; abort can supersede
 * an unfinished stop. The library owns workers, while the application owns camera tracks.
 */
export type CaptureSessionMethods = {
    captureId: string;
    config: Readonly<ResolvedConfiguration>;
    /**
     * Probe and warm up without persisting; ready is returned on success.
     */
    prepare: () => Promise<CaptureResult>;
    /**
     * Prepare automatically and begin capture.
     */
    start: () => Promise<CaptureResult>;
    /**
     * Drain workers and enqueue artifacts and manifest; with a shared queue, remote uploads continue independently.
     */
    stop: () => Promise<CaptureResult>;
    /**
     * Discard work not yet accepted by a shared queue; accepted jobs and in-flight writes can still complete.
     */
    abort: () => Promise<CaptureResult>;
    /**
     * Stop a started session; abort an unstarted one.
     */
    dispose: () => Promise<CaptureResult>;
    /**
     * Read current status and artifact snapshots.
     */
    getResult: () => CaptureResult;
};
/**
 * Frozen lifecycle API; camera ownership stays with the application.
 */
export type CaptureSession = Readonly<CaptureSessionMethods>;
/**
 * Source frame dimensions persisted with a face event, in pixels.
 */
export type FaceEventSourceDimensions = {
    width: number;
    height: number;
};
/**
 * Detector counts and confidence scores retained for frame-level interpretation.
 */
export type FaceDetectionEvidence = {
    rawCount: number;
    eligibleCount: number;
    scores: (number | null)[];
};
/**
 * Crop box coordinates and dimensions in source-frame pixels.
 */
export type FaceEventBoundingBox = {
    originX: number;
    originY: number;
    width: number;
    height: number;
};
/**
 * Selected face score and crop bounds; the box is null when no face was selected.
 */
export type FaceSelectionEvidence = {
    score: number | null;
    boundingBox: FaceEventBoundingBox | null;
    tieBreakOccurred: boolean;
};
/**
 * Persisted frame evidence. `presentationTimeUs` is the scientific timing authority;
 * `wallClockMs` is the wall-clock observation in milliseconds.
 */
export type FaceEventFrame = {
    /**
     * Zero-based frame index within the part.
     */
    frameIndex: number;
    /**
     * Video presentation timestamp, in microseconds.
     */
    presentationTimeUs: number;
    /**
     * Wall-clock timestamp, in milliseconds.
     */
    wallClockMs: number;
    /**
     * Face selection state for this frame.
     */
    state: "default" | "largest" | "held" | "reacquired";
    /**
     * Original frame dimensions, in pixels.
     */
    source: FaceEventSourceDimensions;
    /**
     * Detection counts and scores.
     */
    detection: FaceDetectionEvidence;
    /**
     * Selected face and crop box.
     */
    selection: FaceSelectionEvidence;
    /**
     * Integer crop descriptor used for sampling.
     */
    roi: import("./FaceCropPipeline.worker").FaceRoiDescriptor;
};
/**
 * Serialized sidecar schema v3. An AVI part and this sidecar form one logical artifact.
 */
export type FaceEvents = {
    schema: "face-crop-events-v3";
    captureId: string | null;
    context: JsonObject;
    aviFilename: string | null;
    segmentIndex: number | null;
    partIndex: number | null;
    frameCount: number;
    /**
     * Prior part timing continuity, in microseconds.
     */
    precedingFramePresentationTimeUs: number | null;
    validity: FaceEventsValidity;
    analysis: FaceEventsAnalysis;
};
/**
 * Source dimensions and selection settings associated with the sidecar.
 */
export type FaceEventsValidity = {
    source: FaceEventSourceDimensions | null;
    selectionConfiguration: {
        minDetectionConfidence: number;
        policy: string;
    } | null;
};
/**
 * Per-frame face-detection and crop-selection evidence.
 */
export type FaceEventsAnalysis = {
    frames: FaceEventFrame[];
    output?: {
        format: OutputFormat;
        frameSize: number;
        width: number;
        height: number;
        partSize: PartSizeMetadata;
    };
};
/**
 * Capture identity and study context persisted in the manifest.
 */
export type ManifestCapture = {
    captureId: string;
    filenamePrefix: string | null;
    context: JsonObject;
};
/**
 * Terminal capture summary and frame/part counts.
 */
export type ManifestSummary = {
    status: CaptureStatus;
    reasonCode: CaptureReasonCode | null;
    failureCode: string | null;
    reason: string | null;
    frameCount: number;
    partCount: number;
    faceDetectionMisses: number;
};
/**
 * Sampling algorithm and descriptor version used to produce each frame.
 */
export type ManifestSampling = {
    algorithm: string;
    descriptorVersion: number;
};
/**
 * Encoded video and timestamp contract recorded in the manifest.
 */
export type ManifestOutput = {
    format: string;
    container: string;
    videoCodec: string;
    pixelFormat: string;
    frameSize: number;
    width?: number;
    height?: number;
    partSize?: PartSizeMetadata;
    sampling: ManifestSampling;
    aviHeaderFrameRatePolicy: string;
};
/**
 * One AVI and face-event sidecar part, with its derived header frame rate.
 */
export type ManifestPart = {
    filename: string;
    faceEventsFilename: string;
    segmentIndex: number;
    partIndex: number;
    frameCount: number;
    frameRate: number | null;
    byteLength: number | null;
    width?: number;
    height?: number;
};
/**
 * Ordered parts and the timestamp field authoritative for scientific timing.
 */
export type ManifestAnalysis = {
    output: ManifestOutput;
    timestampAuthority: "presentationTimeUs";
    parts: ManifestPart[];
};
/**
 * Source dimensions as recorded when the manifest is built.
 */
export type ManifestSourceDimensions = {
    width: number | null;
    height: number | null;
} | null;
/**
 * Capability outcome summary included in validity metadata.
 */
export type ManifestCapability = {
    status: string | null;
    failedStage: string | null;
} | null;
/**
 * Per-file upload outcomes for the AVI and its face-event sidecar.
 */
export type ManifestArtifactOutcome = {
    filename: string;
    faceEventsFilename: string;
    status: ArtifactStatus | null;
    avi: {
        status: ArtifactStatus;
    } | null;
    faceEvents: {
        status: ArtifactStatus;
    } | null;
};
/**
 * Capture health and pipeline timing measurements persisted for interpretation.
 */
export type ManifestHealth = {
    faceDetections: number;
    faceDetectionMisses: number;
    acceptedFrames: number;
    frameCallbacks: number;
    accounting: CaptureAccounting | null;
    frameTimings: Record<string, TimingMetric> | null;
    encodingTimings: Record<string, TimingMetric> | null;
    detectorWarmup: DetectorWarmup | null;
};
/**
 * Validity and integrity evidence recorded in the serialized manifest.
 */
export type ManifestValidity = {
    source: ManifestSourceDimensions;
    sourceFailure: SourceFailure | null;
    /**
     * Applied algorithm provenance, if available.
     */
    configuration: ConfigurationMetadata | null;
    /**
     * Startup VideoFrame normalization decision.
     */
    frameNormalization: FrameNormalizationMetadata | null;
    capability: ManifestCapability;
    health: ManifestHealth;
    artifactOutcomes: ManifestArtifactOutcome[];
};
/**
 * Optional verbose capability and detector warmup evidence.
 */
export type ManifestDiagnostics = {
    capability: Capability | null;
    detectorWarmup: DetectorWarmup | null;
};
/**
 * Serialized manifest schema v1. Separate from CaptureResult.manifest, which is an upload outcome.
 */
export type CaptureManifest = {
    schema: "face-crop-manifest-v1";
    capture: ManifestCapture;
    summary: ManifestSummary;
    analysis: ManifestAnalysis;
    validity: ManifestValidity;
    diagnostics?: ManifestDiagnostics | undefined;
};
