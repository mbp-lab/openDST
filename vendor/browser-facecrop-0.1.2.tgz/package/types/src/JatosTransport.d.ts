/** @typedef {import('./PublicTypes').JatosApi} JatosApi */
/** @typedef {import('./PublicTypes').Transport} Transport */
/**
 * Adapt an explicitly supplied JATOS API object to the capture transport contract.
 * Calls `uploadResultFile(payload, filename)` and resolves only when that call resolves.
 * No global JATOS object is read or modified, and the adapter applies no study selection,
 * camera policy, or deletion side effects.
 *
 * @param {JatosApi} jatosApi API object exposing `uploadResultFile`.
 * @returns {Transport} Frozen promise-based transport adapter.
 * @throws {TypeError} If `uploadResultFile` is not a function.
 */
export function createJatosTransport(jatosApi: JatosApi): Transport;
export type JatosApi = import("./PublicTypes").JatosApi;
export type Transport = import("./PublicTypes").Transport;
