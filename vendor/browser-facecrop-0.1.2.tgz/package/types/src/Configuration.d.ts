/**
 * Validate configuration without coercion and return a frozen object with defaults applied.
 * Unknown keys and invalid values throw; missing fields receive the documented defaults.
 *
 * @param {CaptureConfiguration} [config={}] Partial capture configuration.
 * @returns {ResolvedConfiguration} Fully resolved, frozen configuration.
 * @throws {TypeError|RangeError} If a group, key, or value is invalid.
 */
export function validateConfiguration(config?: CaptureConfiguration): ResolvedConfiguration;
/** Map validated public settings into controller names. @internal @param {ResolvedConfiguration} config @returns {import('./FaceCropCapture').ControllerOptions['configuration']} */
export function controllerConfiguration(config: ResolvedConfiguration): import("./FaceCropCapture").ControllerOptions["configuration"];
export type CaptureConfiguration = import("./PublicTypes").CaptureConfiguration;
export type ResolvedConfiguration = import("./PublicTypes").ResolvedConfiguration;
