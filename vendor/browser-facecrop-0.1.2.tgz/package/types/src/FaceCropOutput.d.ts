/**
 * Create the stable filename shared by an AVI part and its events sidecar.
 * The captureId/filenamePrefix form is preferred; study identity fields remain
 * for legacy internal callers.
 * @internal
 * @param {{filenamePrefix?:string|null,captureId?:string,segmentIndex:number,partIndex:number,studyResultId?:string|number,studyPage?:string|number,videoCounter?:string|number}} identity
 * @returns {string} `.avi.gz` filename
 */
export function createPatchVideoFilename(identity: {
    filenamePrefix?: string | null;
    captureId?: string;
    segmentIndex: number;
    partIndex: number;
    studyResultId?: string | number;
    studyPage?: string | number;
    videoCounter?: string | number;
}): string;
/** @internal @param {{captureId:string,filenamePrefix?:string|null,studyResultId?:string|number,studyPage?:string|number,videoCounter?:string|number}} identity @returns {string} `.json` manifest filename */
export function createCaptureManifestFilename(identity: {
    captureId: string;
    filenamePrefix?: string | null;
    studyResultId?: string | number;
    studyPage?: string | number;
    videoCounter?: string | number;
}): string;
/**
 * @internal Derive the `.face-events.json` name from the matching AVI filename.
 * @param {Parameters<typeof createPatchVideoFilename>[0]} identity
 * @returns {string}
 */
export function createFaceEventsFilename(identity: Parameters<typeof createPatchVideoFilename>[0]): string;
/**
 * Derive an integer AVI header rate from presentation timestamps in this part,
 * including the prior-part timestamp when available. It never uses wall clock
 * time and rejects missing, unsafe, or non-increasing timestamps.
 * @internal
 * @param {Pick<FaceCropPart,'faceEvents'>|{faceEvents:FaceEvents}} part
 * @returns {number} Clamped integer frames per second in [1, 120]
 */
export function resolveAviFrameRate(part: Pick<FaceCropPart, "faceEvents"> | {
    faceEvents: FaceEvents;
}): number;
/** @internal Build a complete RIFF AVI in memory from consecutive BGR24 frames. */
/**
 * Build a RIFF AVI byte stream containing top-down square, 24-bit BGR frames.
 * Direct low-level calls default the header rate to 30 fps; normal pipeline
 * encoding supplies a timestamp-derived rate instead.
 * @internal
 * @param {{bytes:Uint8Array,frameCount:number,frameRate?:number,resolution?:number}} input
 * @returns {Uint8Array} Complete uncompressed AVI file bytes
 */
export function buildUncompressedAvi({ bytes, frameCount, frameRate, resolution }: {
    bytes: Uint8Array;
    frameCount: number;
    frameRate?: number;
    resolution?: number;
}): Uint8Array;
/** RFC 1952 gzip containing RFC 1951 stored blocks, with a deterministic size bound. */
export function buildStoredGzip(bytes: any): Uint8Array<any>;
/**
 * @internal Encode a part as a Blob containing gzip-compressed AVI bytes.
 * Omitted frameRate is derived from presentationTimeUs and clamped to 1–120 fps.
 * @param {FaceCropPart} part
 * @param {number} [frameRate] AVI header rate in frames per second
 * @returns {Promise<Blob>}
 */
export function encodeGzipAvi(part: FaceCropPart, frameRate?: number): Promise<Blob>;
/**
 * Convert a sealed worker part into transferable gzip bytes plus its versioned
 * JSON sidecar. The returned ArrayBuffer is transferred to the main-thread sink.
 * @internal
 * @param {FaceCropPart} part
 * @returns {Promise<EncodedPatchArtifact>}
 */
export function encodePatchArtifact(part: FaceCropPart): Promise<EncodedPatchArtifact>;
/** @typedef {import('./PublicTypes').FaceEvents} FaceEvents */
/** @typedef {import('./FaceCropPipeline.worker').FaceCropPart} FaceCropPart */
/** @typedef {{captureId:string, segmentIndex:number, partIndex:number, filename:string, faceEventsFilename:string, frameCount:number, frameRate:number, gzipBytes:ArrayBuffer, faceEvents:FaceEvents}} EncodedPatchArtifact An encoded AVI.gz artifact paired with its frame evidence sidecar. */
/** @typedef {import('./PublicTypes').ArtifactStatus} UploadFileStatus Runtime file-ledger states, including outcomes beyond the tracker enum. */
/** @typedef {{uploadId:string,filename:string,status:UploadFileStatus,attempts:number,error?:unknown}} UploadFileOutcome */
/** @typedef {import('./PublicTypes').ArtifactWrite} UploadRequest Payload passed to the configured transport. */
/**
 * @typedef {Object} FaceCropSinkOptions
 * @property {(request:UploadRequest)=>PromiseLike<unknown>|unknown} [write] Transport callback.
 * @property {(payload:Blob|string,filename:string)=>unknown} [uploadResultFile] Legacy transport callback.
 * @property {{registerUpload:(uploadId:string)=>void,settleUpload:(uploadId:string,status:import('./uploadState').UploadTrackerStatus)=>void}} [uploadTracker]
 * @property {(event:import('./PublicTypes').ArtifactEvent)=>void} [onArtifact]
 * @property {(milliseconds:number)=>Promise<void>} [sleep]
 * @property {number} [maxPendingParts] Maximum retained encoded parts, at most MAX_PENDING_PATCH_PARTS.
 * @property {number} [maxAttempts] Maximum attempts for each file.
 * @property {number} [retryDelayMs] Linear retry base delay.
 * @property {any} [uploadQueue] Shared study upload scheduler.
 */
/** Public format identifier for gzip-compressed, uncompressed 72×72 BGR24 AVI parts. */
export const PATCH_VIDEO_FORMAT_VERSION: "patch-video-avi-gzip-bgr24-v1";
/** @internal Default AVI header frame rate when explicitly requested by a low-level caller, in frames per second. */
export const PATCH_VIDEO_FRAME_RATE: 30;
/** Public sidecar schema identifier; retain its literal when the schema contract is unchanged. */
export const FACE_EVENTS_FORMAT_VERSION: "face-crop-events-v3";
/** @internal Maximum encoded parts retained while the upload queue is backpressured. */
export const MAX_PENDING_PATCH_PARTS: 2;
/** @internal Maximum attempts made for each uploaded file. */
export const MAX_UPLOAD_ATTEMPTS: 3;
/**
 * Serial upload sink for encoded parts and the capture manifest. It retains at
 * most the configured number of pending parts, retrying each file separately.
 * A part's sidecar is attempted only after its AVI succeeds. Abort discards
 * work not yet started; started transport calls remain observable and may have
 * uncertain remote outcomes.
 * @internal
 */
export class FaceCropSink {
    /** @param {FaceCropSinkOptions} options */
    constructor({ write, uploadResultFile, uploadTracker, onArtifact, sleep, uploadQueue, maxPendingParts, maxAttempts, retryDelayMs }: FaceCropSinkOptions);
    uploadSessionId: number;
    pending: any[];
    tail: Promise<void>;
    results: any[];
    accepting: boolean;
    aborted: boolean;
    entries: any[];
    fileEntries: any[];
    abortWait: Promise<any>;
    resolveAbortWait: (value: any) => void;
    /** @param {EncodedPatchArtifact} part Queue a paired AVI and events artifact with backpressure. */
    enqueuePart(part: EncodedPatchArtifact): Promise<void>;
    /** Stop accepting parts and wait for all queued uploads; returns per-part outcomes. */
    finalize(): Promise<{
        parts: any[];
        deferred: boolean;
        settled: Promise<{
            parts: any[];
        }>;
    } | {
        parts: any[];
        deferred?: undefined;
        settled?: undefined;
    }>;
    /** Discard not-yet-started artifacts and report any still-running completions. */
    abort(): {
        status: string;
        artifacts: any[];
        pendingCompletions: any[];
    };
    inventory(): any[];
    pendingResult(identity: any): {
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        filename: any;
        faceEventsFilename: any;
        width: any;
        height: any;
        status: string;
        avi: {
            filename: any;
            status: string;
            attempts: number;
        };
        faceEvents: {
            filename: any;
            status: string;
            attempts: number;
        };
    };
    uploadEntry(entry: any): Promise<{
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        filename: any;
        faceEventsFilename: any;
        width: any;
        height: any;
        status: string;
        avi: {
            filename: any;
            status: string;
            attempts: number;
        };
        faceEvents: {
            filename: any;
            status: string;
            attempts: number;
        };
    } | {
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        filename: any;
        faceEventsFilename: any;
        status: string;
        avi: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
        faceEvents: {
            uploadId: string;
            filename: any;
            status: string;
            attempts: number;
        };
        width?: undefined;
        height?: undefined;
    } | {
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        width: any;
        height: any;
        filename: any;
        faceEventsFilename: any;
        status: string;
        avi: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
        faceEvents: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
    }>;
    /**
     * Upload a standalone artifact, used for the capture manifest and diagnostics.
     * @param {string|(()=>string|PromiseLike<string>)} payload
     * @param {string} filename
     * @param {string} [uploadId]
     * @param {(status:'accepted'|'discarded')=>void} [onAdmission]
     */
    writeArtifact(payload: string | (() => string | PromiseLike<string>), filename: string, uploadId?: string, onAdmission?: (status: "accepted" | "discarded") => void): Promise<{
        uploadId: any;
        filename: any;
        status: string;
        attempts: number;
    } | {
        uploadId: any;
        filename: any;
        status: string;
        attempts: any;
        error: any;
    } | null>;
    notify(identity: any, uploadId: any, filename: any, status: any, attempts?: number): void;
    uploadPart(part: any, entry: any): Promise<{
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        filename: any;
        faceEventsFilename: any;
        width: any;
        height: any;
        status: string;
        avi: {
            filename: any;
            status: string;
            attempts: number;
        };
        faceEvents: {
            filename: any;
            status: string;
            attempts: number;
        };
    } | {
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        filename: any;
        faceEventsFilename: any;
        status: string;
        avi: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
        faceEvents: {
            uploadId: string;
            filename: any;
            status: string;
            attempts: number;
        };
        width?: undefined;
        height?: undefined;
    } | {
        captureId: any;
        segmentIndex: any;
        partIndex: any;
        frameCount: any;
        frameRate: any;
        byteLength: any;
        width: any;
        height: any;
        filename: any;
        faceEventsFilename: any;
        status: string;
        avi: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
        faceEvents: {
            uploadId: any;
            filename: any;
            status: string;
            attempts: number;
        } | {
            uploadId: any;
            filename: any;
            status: string;
            attempts: any;
            error: any;
        };
    }>;
    /** @internal Retry one file independently; an aborted in-flight request may have an uncertain remote result. */
    uploadWithRetry(payload: any, filename: any, uploadId: any, partEntry?: null, kind?: string, existingLedger?: null): Promise<{
        uploadId: any;
        filename: any;
        status: string;
        attempts: number;
    } | {
        uploadId: any;
        filename: any;
        status: string;
        attempts: any;
        error: any;
    }>;
}
export type FaceEvents = import("./PublicTypes").FaceEvents;
export type FaceCropPart = import("./FaceCropPipeline.worker").FaceCropPart;
/**
 * An encoded AVI.gz artifact paired with its frame evidence sidecar.
 */
export type EncodedPatchArtifact = {
    captureId: string;
    segmentIndex: number;
    partIndex: number;
    filename: string;
    faceEventsFilename: string;
    frameCount: number;
    frameRate: number;
    gzipBytes: ArrayBuffer;
    faceEvents: FaceEvents;
};
/**
 * Runtime file-ledger states, including outcomes beyond the tracker enum.
 */
export type UploadFileStatus = import("./PublicTypes").ArtifactStatus;
export type UploadFileOutcome = {
    uploadId: string;
    filename: string;
    status: UploadFileStatus;
    attempts: number;
    error?: unknown;
};
/**
 * Payload passed to the configured transport.
 */
export type UploadRequest = import("./PublicTypes").ArtifactWrite;
export type FaceCropSinkOptions = {
    /**
     * Transport callback.
     */
    write?: ((request: UploadRequest) => PromiseLike<unknown> | unknown) | undefined;
    /**
     * Legacy transport callback.
     */
    uploadResultFile?: ((payload: Blob | string, filename: string) => unknown) | undefined;
    uploadTracker?: {
        registerUpload: (uploadId: string) => void;
        settleUpload: (uploadId: string, status: import("./uploadState").UploadTrackerStatus) => void;
    } | undefined;
    onArtifact?: ((event: import("./PublicTypes").ArtifactEvent) => void) | undefined;
    sleep?: ((milliseconds: number) => Promise<void>) | undefined;
    /**
     * Maximum retained encoded parts, at most MAX_PENDING_PATCH_PARTS.
     */
    maxPendingParts?: number | undefined;
    /**
     * Maximum attempts for each file.
     */
    maxAttempts?: number | undefined;
    /**
     * Linear retry base delay.
     */
    retryDelayMs?: number | undefined;
    /**
     * Shared study upload scheduler.
     */
    uploadQueue?: any;
};
