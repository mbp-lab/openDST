# Building and testing the source checkout

This guide is for contributors and applications consuming source. Release consumers receive built files and should start with the [integration guide](integration.md). These commands require the source checkout; build scripts and test harnesses are not included in the installed release package.

## Toolchain and runtime requirements

The supported project toolchain is Node 22.x with npm 10.x, exercised on Node 22.16.0/npm 10.9.2. The release package also declares those versions in its `engines` metadata. Installation tooling may warn or enforce that declaration, depending on its settings. The packaged staging helper runs in Node as part of the consumer build workflow; no older Node compatibility range is currently claimed.

Node is not a browser runtime requirement. Browser capture depends on video-frame and worker APIs, reachable runtime assets, and HTTPS or localhost. Preparation checks capabilities. An application using an older toolchain needs its own validation; package loading alone does not validate staging or application bundling.

## Build and source checks

```sh
git clone https://github.com/mbp-lab/browser-facecrop.git
cd browser-facecrop
npm ci
npm run build
npm run verify:dist
npm run check:docs
npm test
```

When consuming the checkout as a submodule, initialize it with `git submodule update --init --recursive` first.

JSDoc generates the ignored `types/` directory. Do not edit declarations directly; follow the [documentation workflow](documentation.md). `check:docs` validates declarations, editor help, and local Markdown links. See [release packaging](releasing.md) for tarball and installed-consumer checks.

## Build outputs

The lockfile pins build/test tools, TensorFlow.js 4.22.0, its WASM backend 4.22.0, and BlazeFace 0.1.0. The build writes:

| Output under `dist/` | Purpose |
|---|---|
| `facecrop.js` | UMD core for plain scripts and package loading |
| `facecrop.module.js` | ES-module bridge for bundler consumers |
| `facecrop.worker.js` | Classic analysis worker |
| `tfjs/4.22.0/` | TensorFlow.js, WASM, detector, and model assets |
| `asset-manifest.json` | Package version and SHA-256 runtime directory hash |
| Third-party license text and notices | Bundled dependency licensing |

`verify:dist` checks the required file set and recomputes the runtime hash. Generated declarations and Markdown docs are outside that hash. Docs can change the tarball checksum while leaving the runtime hash unchanged.

For deployment, use the [staging workflow](integration.md#2-stage-and-serve-the-runtime). To stage a source build, pass the checkout's `dist/` and application-owned destinations to `stageDistribution` from `scripts/stage-distribution.cjs`.

## Browser acceptance

A real Chromium run checks classic worker loading, TensorFlow.js WASM/model fetches, transferred frames, completed artifact writes, and abort behavior. Playwright and its Chromium binary stay outside the normal library lockfile and install:

```sh
npm install --prefix /tmp/facecrop-test-tools --no-save --package-lock=false playwright
PLAYWRIGHT_MODULE=/tmp/facecrop-test-tools/node_modules/playwright /tmp/facecrop-test-tools/node_modules/.bin/playwright install chromium
PLAYWRIGHT_MODULE=/tmp/facecrop-test-tools/node_modules/playwright npm run test:browser
```

Run after building `dist/`. The smoke test serves that distribution under a nested mount and uses a headless canvas stream, not a physical camera or real backend.

The sustained check uses the same external Playwright installation and checks one- and two-worker runs, slow-storage abort, and resource release:

```sh
PLAYWRIGHT_MODULE=/tmp/facecrop-test-tools/node_modules/playwright \
FACECROP_ASSERT_FRAME_RELEASE=1 FACECROP_REQUIRE_FRAME_OBSERVATION=1 \
FACECROP_ASSERT_TRANSPORT_ACK_RELEASE=1 node tests/browser-sustained.cjs
```

The sustained harness accepts an explicit distribution through `FACECROP_DISTRIBUTION` and a mount through `FACECROP_BROWSER_MOUNT`. Set the mount to `/` for root deployment; its default checks a nested mount. See [retention diagnostic and earlier evidence](provenance.md#retention-diagnostic). Camera/device and production-storage validation still belong to the application.
