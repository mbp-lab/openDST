# Documentation and declaration workflow

JavaScript JSDoc in authored source is the canonical contract for generated API
declarations. `types/` is generated and ignored; edit source annotations, then
regenerate it with `npm run build:types`. Run `npm run check:docs` to validate
the documentation and generated declaration contract before submitting a
change. Do not hand-edit generated files.

## Documentation structure

The [README](../README.md) gives purpose, essential constraints, and the first
capture. The [integration guide](integration.md) follows installation, deployment,
session inputs, lifecycle, upload tracking, and application validation in order.
The [API reference](api.md) owns detailed JavaScript contracts and configuration
tables. The [React guide](../react/README.md) owns hook-specific behavior, while
the [output guide](metadata.md) explains scientific interpretation. Contributor
commands belong in the [build](building.md) and [release](releasing.md) guides.

Keep each detailed explanation in its owning guide; link to it from walkthroughs
and examples. Examples should use the same import choices, terminology, result
checks, and lifecycle ordering as the guide. Keep application-specific audit
findings outside library documentation.

## Coverage boundary

Document the browser library's exported core API and the optional React adapter.
Their public function parameters, return values, thrown errors, lifecycle
behavior, and shared data shapes belong in source JSDoc. Put a reusable type
where its owning API is defined; keep a type local when it is only used by one
module. Mark source-exported implementation helpers `@internal` to distinguish
them from supported package APIs. Package entry exports define the supported
surface; internal declarations may appear in the generated dependency tree.

Use JSDoc on authored JavaScript under `src/` and `react/`. Keep concise file
comments on diagnostic harnesses where they explain purpose and prerequisites.
Tests are executable behavioral contracts, not a source of API documentation;
do not add per-test docblocks. Build and staging scripts may document reusable
helpers, transaction and recovery behavior, and filesystem assumptions.

Python is a separate package. Its Python docstrings and `python/README.md` own
that API; do not mirror its types into JavaScript declarations. Exclude
`dist/`, generated `types/`, TensorFlow.js/BlazeFace vendor files and model
assets from source documentation and declaration generation.

## Contributor checklist

When changing a public JavaScript contract:

1. Update the source JSDoc beside the implementation, including typed
   parameters, return values, and errors where they are part of the contract.
2. Update or add boundary typedefs at the API that owns those shapes. Keep
   optional values and lifecycle states aligned with runtime behavior.
3. Regenerate declarations with `npm run build:types`; review the resulting
   `types/` output locally, but do not commit it.
4. Run `npm run check:docs` and ensure generated declarations have no drift.
5. Update the relevant README or `docs/` guide when usage, deployment,
   processing, metadata, or release behavior changes.

For internal changes, document only a reusable boundary or non-obvious
invariant. Avoid comments that paraphrase statements already clear from the
code. Keep generated output and vendored upstream material out of authored
documentation changes.

## Writing contracts

Put purpose and behavior before typed `@param` and `@returns` tags. Document
synchronous validation errors with `@throws`; describe asynchronous failure
results in prose. Specify units, optional/null values, ownership, mutation,
side effects and ordering where they affect callers. Prefer literal unions for
versioned formats and status/message kinds, and named `@typedef`/`@callback`
contracts for reused shapes. Keep each typedef in its own docblock so its hover
description describes that type. Use `unknown` for opaque diagnostic details,
and narrow it before use; avoid `any` on public contracts.

Public APIs opt into `// @ts-check`; internals receive focused boundary annotations
without blanket type checking. `npm run verify:types` detects missing, unexpected,
or stale declaration files. The package build/prepack generates and verifies
declarations outside the browser distribution hash. `check:docs` compiles positive
and negative consumer fixtures and checks language-service hover descriptions.
It also checks local Markdown links and heading anchors in the README, guides,
React README, and example documentation. Run
`node scripts/check-docs.cjs --package-root /absolute/path/to/installed/browser-facecrop`
from the source checkout to validate an installed release's declarations and links.
External links are not fetched. Checkout-only resources must be labeled as such;
use repository links for resources absent from the JavaScript package.
