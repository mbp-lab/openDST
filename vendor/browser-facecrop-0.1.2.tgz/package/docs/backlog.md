# Follow-up work

These are open investigations, not promised capabilities. Startup currently chooses one frame-normalization transform; per-frame orientation tracking remains open even though startup orientation calibration and explicitly tagged full/limited BT.709 NV12 conversion are implemented.

## Capture correctness and compatibility

- Investigate WebKit orientation or geometry changes during capture. Detect per-frame changes where the browser exposes them; normalize supported transitions or report a clear incomplete-capture outcome, with regression coverage. Do not assume such changes can safely be reported as non-fatal.
- Add stable failure codes and a failure-time observed-state snapshot for frame-normalization preflight and runtime failures. Include expected and actual format, dimensions, rotation, flip, and copy layout when available. Keep these distinct from the existing source lifecycle and dimension failure codes.
- Extend physical-device camera validation across Android and iOS browsers, including orientation changes and color-space metadata/conversion. Record the device and browser matrix and observed limitations.
- Assess additional `VideoFrame` formats and layouts required by the supported device matrix. The current paths normalize explicitly tagged BT.709 NV12 or use the browser's packed-RGBA conversion; an Android run exercised I420 through that RGBA fallback, not native I420 processing. Add formats only with color and orientation fidelity tests.

## Performance and scientific evaluation

- Evaluate analysis-FPS caps and adaptive throttling as separate scientific proposals. Quantify their effects on sampling, timestamps, and evidence before adding either control.
- Profile sustained capture on physical mobile devices for CPU, JavaScript and native memory, battery, callback gaps, dropped frames, and thermal behavior. Report device, browser, and capture settings.
- Compare JavaScript area-resampling and BGR24 AVI+gzip with an FFmpeg/WASM candidate on target devices. Measure pixel and timing equivalence, artifact size, throughput, startup cost, and peak memory before considering a replacement.
- Benchmark full-frame allocation and reuse at representative high resolutions and with concurrent sessions. Treat ROI-only extraction as a separate scientific proposal.
- Measure native-frame, GPU/driver, and process memory on target browsers during sustained and concurrent sessions. Keep JavaScript retention checks as a separate signal; they do not account for all native or GPU memory.

## Deployment validation

- Validate capture and upload behavior against a production JATOS deployment: complete captures, cancellation and late upload settlement, configured request limits, and persistence through the deployed study URL. A completed local JATOS run verified all parts, sidecars, and manifests across a task transition. A separate local Android run exercised I420-to-RGBA conversion and settlement of accepted parts after cancellation; because it was canceled, it did not verify Android capture finalization. These runs do not establish production behavior.

The application remains responsible for camera acquisition, study caching and service-worker policy, navigation, retention, and participant withdrawal.
