# JavaScript API reference

This guide is the lookup reference for the public browser API. Follow the [integration guide](integration.md) for implementation order and the [React guide](../react/README.md) for hook-specific behavior. JavaScript JSDoc is canonical for signatures and editor declarations; see the [documentation workflow](documentation.md).

## Runtime exports

The package exports `createCaptureSession(options)`, `createUploadQueue({transport})`, `validateConfiguration(config)`, `createJatosTransport(jatosApi)`, `PATCH_VIDEO_FORMAT_VERSION`, and `FACE_EVENTS_FORMAT_VERSION`. The JSDoc contracts (including `CaptureOptions`, `CaptureResult`, `CaptureEvent`, and configuration types) are editor-only type information, not runtime exports.

`validateConfiguration` validates overrides without creating a session. The format constants identify the default 72-pixel recording format and the sidecar schema. Non-default dimensions use video format v2 as reported by each capture's output metadata; see the [output guide](metadata.md).

For multi-task studies, create one queue and pass it to each capture session. The queue serializes writes and retains at most two queued or active artifact groups in memory; session stop waits for capture processing and queue admission, while remote uploads continue. Artifact events retain their normal pending and settled meanings. A shared queue lives only as long as its JavaScript page and does not persist across reloads.

```js
const transport = createJatosTransport(jatos);
const uploadQueue = createUploadQueue({transport});
const session = createCaptureSession({video, assetBaseUrl, uploadQueue});
```

## Session options

`createCaptureSession` validates and snapshots its inputs, then returns a frozen session object. Construction does not request camera access, create workers, persist artifacts, or change globals. Invalid options throw synchronously (`TypeError` or `RangeError`).

| Option | Required/default | Contract |
|---|---|---|
| `video` | Required | Application-owned, playing video element |
| `assetBaseUrl` | Required | Absolute HTTP(S) directory URL, no query/fragment; a missing trailing slash is added |
| `transport` | Required unless using a queue | Object with `write({filename, payload})`; see [transport](#transport) |
| `uploadQueue` | Optional | Queue from `createUploadQueue`, shared across sessions that use its transport |
| `captureId` | Generated when omitted | Custom ID must be unique across recordings and contain only ASCII letters, digits, `_`, or `-` |
| `filenamePrefix` | Empty string | Nonempty values use the same character restrictions as capture IDs |
| `context` | `{}` | Plain JSON object, defensively copied; finite numbers and no cycles |
| `config` | Library defaults | Partial [configuration](#configuration) with strict value validation |
| `onEvent` | No observer | Function receiving [events](#events) |

For a bundler application with a staged bridge:

```js
import {createCaptureSession} from './facecrop-generated/facecrop';

const session = createCaptureSession({
  video, // application-owned, playing HTMLVideoElement
  assetBaseUrl, // absolute directory URL from the integration guide
  captureId: 'participant-42-task-a',
  context: {studyPage: 'task-a'},
  transport: {write: ({filename, payload}) => saveArtifact(filename, payload)},
  onEvent: event => uploadTracker(event),
  config: {roi: {scale: 1.4}}
});
```

## Configuration

`validateConfiguration(config = {})` applies defaults and returns a frozen resolved configuration. `session.config` is that same resolved configuration. Unknown keys, arrays, non-plain objects, coercible strings, and out-of-range values throw synchronously. Shape/key errors and non-boolean `uploadDiagnostics` use `TypeError`; invalid numeric settings use `RangeError`, including strings and non-finite values. Missing fields receive defaults; explicitly supplied invalid values do not.

| Setting | Default | Accepted values |
|---|---:|---|
| `roi.smoothingTauMs` | `100` | integer milliseconds, 0–10,000; 0 disables smoothing |
| `roi.scale` | `1.4` | number, 1–3 |
| `roi.verticalShiftRatio` | `0.15` | number, -1–1; positive shifts the crop upward |
| `detector.minConfidence` | `0.5` | number, 0–1 |
| `pipeline.analysisWorkerCount` | `2` | integer, 1 or 2 |
| `persistence.maxAttempts` | `3` | integer, 1–10 |
| `persistence.retryDelayMs` | `100` | integer milliseconds, 0–60,000 |
| `output.resolution` | `72` | integer square width/height in pixels, 16–512 and divisible by 4 |
| `output.maxPartMiB` | `4` | `null` or MiB from 0.03125–32; fractional values are rounded down to whole bytes, and the minimum is checked against two frames |
| `uploadDiagnostics` | `false` | boolean |

Retry delay is multiplied by the attempt number. `output.resolution` sets the square BGR24 output width and height; `72` preserves the existing `patch-video-avi-gzip-bgr24-v1` format. Other resolutions use format v2. The width must be divisible by four for AVI row alignment. `output.maxPartMiB` sets a conservative encoded AVI part ceiling in MiB (`1 MiB = 1,048,576 bytes`), defaulting to 4 MiB. Fractional values are rounded down to whole bytes; for example, `0.1` MiB becomes 104,857 bytes. Its range is 0.03125–32 MiB, and its resolved size must fit the conservative storage bound for two frames, including AVI and gzip overhead. Explicit `null` keeps the legacy raw output buffer budget, which yields 539 frames per part at 72×72; at another resolution the same byte budget holds fewer frames. The ceiling covers `.avi.gz` files only, not sidecars, manifests, or diagnostic timelines. The persisted `analysis.output.partSize.maxPartBytes` metadata remains expressed in bytes. `uploadDiagnostics: true` enables verbose troubleshooting diagnostics, console logging, and incremental upload of a session timeline through the configured transport. It defaults to `false`. `diagnostics` is no longer a configuration key and is rejected as unknown. Health and scientific provenance are retained regardless of this setting.

## Session methods

Async lifecycle operations return `Promise<CaptureResult>` and resolve structured results for ordinary runtime failures. Inspect status rather than assuming a fulfilled promise means success. Repeated prepare/start calls share their respective promises; terminal operations reuse the terminal promise, except abort can supersede an unfinished stop. Unexpected implementation or cleanup errors may still reject. `getResult()` is synchronous.

| Method | Behavior |
|---|---|
| `prepare()` | Probe browser capability and prepare processing resources, without persistence. Success reports `ready`. With diagnostics enabled, records are collected in memory only. |
| `start()` | Prepare as needed, enable diagnostic persistence, then begin capture. Previously collected preparation records are eligible for upload. |
| `stop()` | Drain capture processing and write or enqueue a manifest. With a shared queue, stop does not wait for network settlement and returned artifact snapshots can still be pending; otherwise it awaits uploads as before. |
| `abort()` | Cancel capture and discard work not yet accepted by a shared queue. Already queued shared uploads continue; without a shared queue, existing abort behavior applies. |
| `dispose()` | Stop if started, otherwise abort. |
| `getResult()` | Read current status, artifact inventory, and result fields without waiting. |

The session exposes `captureId`, resolved `config`, and these methods. The session and configuration are frozen. Failed startup cleans up processing resources before returning its structured result; an additional abort is unnecessary for that cleanup. Abort after finalization is a no-op. Terminal sessions are not reusable for another recording.

The application owns the video, camera tracks, permission flow, navigation, and deletion policy; see the [lifecycle walkthrough](integration.md#4-connect-the-capture-lifecycle). Workers belong to the library. Processing buffers and encoded payloads are released after processing and transport settle; result objects retained by your code remain application-owned.

## Results and statuses

`CaptureResult` contains `status`, `reasonCode`, `reason`, `failureCode`, `sourceFailure`, `capture` (`captureId` and copied `context`), `statistics`, `capability`, `output` (applied dimensions and part behavior), `artifacts`, `diagnosticUploads`, `manifest`, and `observerErrors`. `diagnosticUploads` is `{artifacts, droppedRecords}`: public snapshots of diagnostic timeline upload outcomes and the number of buffered records dropped to honor the memory bound. Diagnostic upload failures are reported there and do not change the capture status. Source failures describe observed stream/dimension state; they do not identify who or what caused it. Capability check details vary by browser; full troubleshooting details are collected when `uploadDiagnostics: true`.

| Result status | Meaning |
|---|---|
| `disabled` | Newly constructed, not prepared |
| `ready` | Preparation succeeded; recording has not started |
| `unsupported` | Capability or pre-start setup failed |
| `capturing` | Recording started |
| `complete` | Normal finalization succeeded |
| `incomplete` | Capture or required persistence failed; useful partial output may exist |
| `aborted` | Interrupted by the application; in-flight artifacts may still persist |

The high-level `reasonCode` is `CAPABILITY_UNSUPPORTED`, `CAPTURE_INCOMPLETE`, or `CAPTURE_ABORTED` for the corresponding terminal state; otherwise it is `null`. `failureCode` is a more specific video source failure code when present. Runtime pipeline problems are represented in the result, usually as `incomplete`, rather than rejecting the operation promise. Unsupported startup waits for diagnostic timeline uploads before `start()` resolves when upload diagnostics are enabled, unless a shared queue is configured; then it waits for queue admission and exposes later outcomes through artifact events and refreshed result snapshots.

Artifact results are public snapshots containing `filename`, `status`, and `attempts`; they do not expose internal completion promises or upload IDs. Artifact states are `pending`, `succeeded`, `uncertain`, `failed`, `discarded`, and `not_attempted`. `discarded` means abort prevented a write from starting. `not_attempted` can mean a dependent sidecar was skipped after AVI retries failed. The session `manifest` reports the manifest filename and write status separately because the stored manifest cannot describe its own later write outcome.

The result defensively copies `capture.context` and artifact arrays/entries, including diagnostic artifact snapshots. `statistics`, `capability`, `sourceFailure`, and the manifest outcome may contain references shared with the session; treat nested result data as read-only. `getResult()` is a snapshot, so read it again for later state. Observer exceptions do not escape into capture processing; serializable `{name, message}` entries accumulate in `observerErrors`.

## Events

`onEvent(event)` receives a discriminated union; always narrow on `event.type`. Status events (`type: 'status'`) contain capture status and metadata. Artifact events carry an `artifact` with `uploadId`, `captureId` (null for manifest writes), `filename`, `status`, and `attempts`.

| Event type | Purpose |
|---|---|
| `status` | Controller status and processing metadata; preparation readiness is read from its result, not a `ready` event |
| `artifact_registered` | Once per upload ID, before its first progress notification |
| `artifact` | Persistence progress, including repeated pending retries |
| `artifact_settled` | Once per upload ID, after its first terminal progress notification |

For each upload ID, notification order is:

1. `artifact_registered` once, immediately before its first progress notification.
2. `artifact` progress; `pending` may repeat while retries occur.
3. `artifact_settled` once, immediately after the first terminal progress notification.

Skipped artifacts are registered even when no write starts. Diagnostic timeline files use these same artifact lifecycle notifications and are tracked through the configured transport. If already terminal at first notification, registration, progress, and settlement are emitted in that order during the same notification call. Settlement means an outcome was reached, not that it succeeded or was deleted. A write already in flight may produce progress/settlement after `abort()` returns. Keep the observer connected while tracking outstanding writes. Observer exceptions are recorded and do not suppress subsequent notifications. See the [upload-tracking walkthrough](integration.md#5-connect-upload-tracking-when-needed).

With upload diagnostics enabled, records are persisted in JSON batches. The library flushes when a batch reaches 64 KiB, when the page becomes hidden, at page exit, or after five seconds with buffered records. Events that arrive while a write is active are collected for the next batch. Each file is immutable and named `<prefix>_<captureId>_diagnostics_000001.json`, with an increasing batch number. Individual records are limited to 32 KiB and the unsent buffer to 256 KiB. An oversized record is represented by a truncation marker; when the buffer overflows, the oldest unsent records are dropped and counted in `diagnosticUploads.droppedRecords`. Sequence numbers preserve the order and reveal gaps. Only one diagnostic write is active per session. Diagnostic artifact notifications are not themselves added to the timeline.

## Transport

`transport.write({filename, payload})` must return a promise or thenable resolving after persistence is acknowledged. Payloads are gzip AVI `Blob`s or JSON strings, including diagnostic timeline batches when enabled. Rejection is not proof that storage did not happen; a write rejected after retries is `uncertain`. The library's retry policy controls subsequent attempts. Retrying a diagnostic batch reuses its exact filename and payload.

Abort prevents new writes and does not cancel or wait for a transport request already in flight. With a shared queue, jobs already accepted by that queue continue; work not yet accepted is discarded. Remote deletion and participant withdrawal policy belong to the application/backend.

## JATOS adapter

`createJatosTransport(jatosApi)` adapts an explicitly supplied object with `uploadResultFile(payload, filename)`. It returns a frozen transport and wraps synchronous return values or thrown errors in a promise. It does not read or modify a global JATOS object.
Adapter construction throws `TypeError` if `uploadResultFile` is missing.

```js
const transport = createJatosTransport(jatos);
const session = createCaptureSession({video, assetBaseUrl, transport});
```
