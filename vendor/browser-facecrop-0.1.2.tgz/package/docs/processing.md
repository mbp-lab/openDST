# Face-crop implementation notes

This directory contains the standalone face-crop recording pipeline that consumes an application-owned video element. Public configuration and deployment guidance belongs in `README.md`; output interpretation belongs in `docs/metadata.md`; this file records
the internal design contract for contributors.

See [the documentation workflow](documentation.md) for JSDoc and declaration
updates when changing public JavaScript contracts.

## Runtime flow

`FaceCropCaptureController` schedules `VideoFrame` instances, distributes them
to analysis workers, forwards their transferable results to one ordered assembly
worker, forwards sealed parts to an encoding worker, and coordinates explicit transport writes and retries:

```text
main thread
  -> N analysis workers (native-frame normalization + BlazeFace detection on TensorFlow.js WASM)
  -> 1 assembly worker (source ordering, ROI, downsampling, segmentation)
  -> 1 encoding worker (AVI + gzip)
  -> main-thread FaceCropSink (explicit transport writes and retries)
```

`config.pipeline.analysisWorkerCount` accepts `1` or `2` (default `2`).
The assembly worker buffers at most that many out-of-order results and returns
sealed raw parts with frame evidence to the encoding worker. ROI selection, downsampling,
AVI muxing, and gzip encoding do not run on the main thread.

## Files

- `FaceCropCapture.js`: capability probing, lifecycle, worker routing, upload
  coordination, manifest metadata, and status reporting.
- `FaceCropPipeline.worker.js`: BlazeFace/TFJS WASM analysis and ordered patch assembly.
- `FaceCropOutput.js`: deterministic filenames, AVI encoding, gzip support, and
  the bounded transport sink.
- The corresponding `*.test.js` files define lifecycle, ordering, pixel-layout,
  segmentation, sidecar, and retry contracts.

## Invariants

- The consuming study decides whether to enable face-crop capture. Unsupported APIs or a
  pipeline failure must not block ordinary recording or study completion.
- Analysis workers own and close transferred `VideoFrame` inputs. The assembly
  worker owns ROI state, patch buffers, segmentation, AVI muxing, and encoding.
- Work and out-of-order results are bounded by the configured analysis-worker
  count; source sequences are always committed in order.
- Face selection is deterministic: the largest eligible detection wins, followed
  by stable tie-breakers. Before the first detection, the largest centered square
  is used; during later misses, the last valid ROI is retained.
- A source-dimension change starts a new segment.
- Every saved AVI part has a matching `.face-events.json` sidecar, and a normally stopped capture has
  a manifest. A failed part or sidecar makes the capture incomplete, while upload
  failures remain terminal and observable.

## Scientific contract

- Detection uses vendored TensorFlow.js and BlazeFace browser bundles with the WASM backend. A one-frame main-thread preflight recovers missing quarter-turn orientation by comparing 32×32 presented luminance with native NV12 Y-plane samples. Analysis workers normalize NV12 frames with explicit full- or limited-range metadata, BT.709 primaries and transfer, and a BT.709 or unspecified matrix (honoring plane offsets and strides) directly into rotated packed RGBA. Range-specific conversion is also applied to orientation calibration. Genuine packed RGBA remains a direct path. Normalized pixels are converted directly to RGB tensors without continuous canvas/WebGL processing, and detector assets are loaded from explicit `assetBaseUrl`-relative `tfjs/4.22.0/` assets. The confidence threshold is applied by BlazeFace and recorded in the manifest; legacy delegate and suppression settings are not exposed because they do not affect this detector.
- Selected bounding boxes become bounded square ROIs using the configured scale,
  vertical shift, and time-based exponential smoothing measured between processed
  frames, including detector misses. Sidecar selection states
  are `default`, `largest`, `held`, and `reacquired`.
- Each ROI is deterministically area-resampled from sRGB RGBA source pixels to
  the configured square BGR24 resolution (72 x 72 by default) using pixel-overlap
  weights and half-up rounding. Dimensions other than 72 use AVI format v2.
- The default 4 MiB encoded AVI part ceiling holds 269 72 x 72 BGR24 frames.
  Setting `output.maxPartMiB` to `null` restores the legacy raw output budget of
  8,382,528 bytes, which holds 539 frames. Other configured ceilings impose a
  conservative encoded AVI bound
  in MiB (rounded down to whole bytes at validation);
  the frame cap includes AVI header/index/chunk bytes and worst-case stored gzip
  overhead. Native gzip is kept when it fits, otherwise stored DEFLATE is used,
  followed by a final actual-byte check before upload. The encoded-byte ceiling
  does not include JSON sidecars, manifests, or diagnostic timeline batches.
- Sidecars map AVI frame indexes to monotonic `presentationTimeUs`, callback `wallClockMs`,
  detector state, selected bounding box, and resolved ROI.
- AVI headers use one frame rate per part derived from `presentationTimeUs`.
  Subsequent parts include the preceding frame timestamp as non-video timing
  metadata so singleton parts retain an observed cadence. Capture is callback-driven
  and may skip frames, so scientific timing must use the sidecar
  timestamps rather than inferred AVI cadence.
- A held ROI has no time limit. Analyses must distinguish `held` frames from
  frames backed by a fresh detection.
