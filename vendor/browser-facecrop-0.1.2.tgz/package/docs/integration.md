# Integrating browser-facecrop

This guide takes an existing browser study from package installation to a deployed capture. Start with the [README](../README.md) for purpose and constraints; use the [API reference](api.md) to look up contracts while implementing these steps.

Facecrop processes an application-owned video, manages its workers, produces artifacts, and persists them through your transport. Your application supplies the camera, recording boundaries, study identifiers, feature switches, navigation, and storage policy.

## 1. Install and pin the package

Download the release tarball and checksum from [GitHub Releases](https://github.com/mbp-lab/browser-facecrop/releases). Keep both under your application's `vendor/` directory. For version 0.1.2, verify from that directory:

```sh
cd vendor
shasum -a 256 -c browser-facecrop-0.1.2.tgz.sha256
```

Install from the application root using its existing package-manager and lockfile workflow:

```sh
npm install ./vendor/browser-facecrop-0.1.2.tgz
```

The resulting dependency is a pinned local artifact:

```json
{
  "dependencies": {
    "browser-facecrop": "file:vendor/browser-facecrop-0.1.2.tgz"
  }
}
```

The tarball contains the distribution, editor declarations, guides, examples, and staging helper. Do not run library build commands in an installed release package. For a source checkout, build using the [build guide](building.md), then use that checkout's `dist/` as the staging source. The private package is distributed through GitHub Releases, not the npm registry.

## 2. Stage and serve the runtime

An importable JavaScript entry and a publicly served runtime directory solve different parts of deployment. Importing the API alone does not make its worker, WASM, or model files available in the browser.

| Application setup | Core entry | Runtime deployment |
|---|---|---|
| Application bundler, including CRA | Import the generated ES-module bridge | Stage the complete distribution into public assets |
| Plain browser scripts | Load `facecrop.js` from the deployed distribution | Serve the complete distribution under its hashed directory |
| Package loading or editor tooling | Installed package entry and declarations | Package resolution alone does not deploy runtime assets |

### Application staging script

Starting with 0.1.2, the release includes a reusable helper. It verifies the distribution, installs assets under their content hash, and generates a module bridge plus matching URL metadata. For an application with `src/` and `public/`, create `scripts/stage-facecrop.cjs`:

```js
const path = require('path');
const {stageDistribution} = require('browser-facecrop/scripts/stage-distribution.cjs');
const packageRoot = path.dirname(require.resolve('browser-facecrop/package.json'));
const applicationRoot = path.resolve(__dirname, '..');

stageDistribution(path.join(packageRoot, 'dist'), {
  generatedDirectory: path.join(applicationRoot, 'src/facecrop-generated'),
  publicRoot: path.join(applicationRoot, 'public/assets/facecrop'),
  publicSubpath: '/assets/facecrop/',
  workRoot: applicationRoot
});
```

Adapt these destinations to your application. The generated, public, and existing work directories must support rename on the same filesystem. The helper preserves prior usable output if staging fails; incomplete rollback reports a recovery directory rather than deleting recovery files.

Run staging before development and production builds. Merge these into existing lifecycle scripts if your application already has them:

```json
{
  "scripts": {
    "prestart": "node scripts/stage-facecrop.cjs",
    "prebuild": "node scripts/stage-facecrop.cjs"
  }
}
```

Ignore generated outputs in application git:

```gitignore
/src/facecrop-generated/
/public/assets/facecrop/
```

| Filesystem output | Purpose |
|---|---|
| `src/facecrop-generated/facecrop.js` | ES-module API bridge imported by the bundler |
| `src/facecrop-generated/facecropAssets.json` | `publicSubpath` including the runtime hash and trailing slash |
| `public/assets/facecrop/<hash>/` | Complete worker, TensorFlow.js, WASM, model, and core runtime |

The bridge scopes UMD initialization locally, preserving exports when the application transpiles it. Serve the complete hashed directory unchanged: the classic worker loads sibling assets through `importScripts`.

Old hashed directories are retained so already-open pages can finish fetching assets. Identical runtime bytes can reuse a directory across package versions. Remove old directories only after deployed pages no longer reference them.

### Import the API and construct the deployed URL

From a source file next to `facecrop-generated/`:

```js
import * as Facecrop from './facecrop-generated/facecrop';
import facecropAssets from './facecrop-generated/facecropAssets.json';

// Application-provided absolute deployment directory, ending in '/'.
// Root example:   https://example.org/
// Nested example: https://example.org/study_assets/my-study/
const applicationBaseUrl = new URL('/study_assets/my-study/', window.location.origin);
const assetBaseUrl = new URL(
  facecropAssets.publicSubpath.slice(1),
  applicationBaseUrl
).href;
```

The metadata path begins with `/` because it describes a path beneath the application's public root. Removing that leading slash when resolving against the application deployment directory preserves a nested study mount. For a root deployment, use `new URL('/', window.location.origin)` as the base. Use your framework's configured deployment base; do not assume the current component URL is the application root.

For plain scripts, deploy the complete `dist/` under the hash from `asset-manifest.json`, load its `facecrop.js`, and pass that same absolute directory URL. The [plain-browser example](../examples/plain-browser/index.html) demonstrates this route.

## 3. Supply application-owned inputs

Use your existing playing webcam video. Facecrop neither requests camera permission nor starts or stops camera tracks. Supply a transport whose write promise resolves after persistence, task context as JSON, and optional configuration overrides:

```js
const session = Facecrop.createCaptureSession({
  video,
  assetBaseUrl,
  filenamePrefix: 'speech',
  context: {task: 'speech', trial: 2},
  transport: Facecrop.createJatosTransport(jatosApi),
  config: {roi: {scale: 1.4}},
  onEvent: observeCapture
});
```

Here `video`, `assetBaseUrl`, `jatosApi`, and `observeCapture` are application-provided. The JATOS adapter receives the API explicitly; it does not read a global. A custom transport follows the [same write contract](api.md#transport).

Missing configuration fields use defaults. Convert environment strings into numbers and booleans before passing them. Unknown fields and invalid values throw during construction. See [configuration](api.md#configuration).

Decide which study pages record and which application switches permit uploads. Facecrop does not interpret environment variables or enforce application logging policy. Supply a unique custom capture ID only if needed; otherwise the library generates one. Filenames and context have separate roles; see [session options](api.md#session-options).

## 4. Connect the capture lifecycle

Create a new session for each recording. Construction validates inputs but does not start processing. Keep the session reference until its owner has completed cleanup; no additional controller is required.

### Start and inspect the result

```js
const started = await session.start();
if (started.status !== 'capturing') {
  console.warn('Facecrop did not start', started.reason, started.reasonCode);
  // Release the application's active-session reference and report the outcome.
}
```

`start()` includes preparation. Call `prepare()` earlier to probe support and warm processing resources. With `config.uploadDiagnostics: true`, preparation diagnostics are collected in memory but not written until `start()` enables uploads. A session returned by construction is not evidence that capture started. Diagnostic startup evidence is uploaded incrementally; unsupported startup waits for its diagnostic upload before resolving without a shared queue, or for queue admission when one is configured.

Ordinary startup failures return a structured result and clean up processing resources. Do not abort solely to clean up such a failure; it can replace the reported failure with an aborted outcome. Check results rather than relying only on rejected promises.

Construction errors are synchronous. An optional integration may catch those at its application boundary so invalid setup does not interrupt the ordinary task. Handle unexpected promise rejections separately, with best-effort cleanup and reporting. The library cannot decide whether your study should continue without facecrop or block progression.

### Finalize before navigation

```js
const finalized = await session.stop();
// Inspect status, manifest persistence, and artifact outcomes.
// Advance the task only after this promise settles.
```

Without a shared upload queue, `stop()` drains processing and waits for final persistence, including remaining diagnostic timeline uploads when enabled. With a shared queue, it waits for processing and admission of the session's artifacts to that queue; uploads can settle later, including after the task changes. A resolved promise does not mean every artifact succeeded. Check `result.diagnosticUploads` as well as video artifacts and manifest, and keep upload tracking alive until queued artifacts settle. Diagnostic persistence failure does not by itself change capture status. The [API reference](api.md#results-and-statuses) explains the outcome.

For a multi-task study, create one queue and pass it to each session using `uploadQueue: Facecrop.createUploadQueue({transport})`. The queue is in-memory and shared only within the page lifetime. It bounds outstanding artifact groups and applies backpressure when full.

If recording and navigation live in different components, they may need a shared reference to the same session. Keep reference routing small; do not wrap the session just to reproduce its lifecycle API.

### Abort interrupted teardown

The recording owner should abort its original session on interrupted teardown, including while a normal stop is draining. It must not accidentally abort a newer task's session through a replaced shared reference. Abort after completed finalization is a no-op.

Cleanup that cannot be awaited should handle unexpected rejections as best effort:

```js
void session.abort().catch(error => console.error('Facecrop cleanup failed', error));
```

The [React hook](../react/README.md) aborts on unmount, but React cannot await cleanup. Await stop in the task completion handler before causing unmount.

Without a shared queue, abort prevents new writes and diagnostic retries, and discards unsent diagnostic records; an already-started upload can still persist and settle after abort returns. With a shared queue, abort also leaves already accepted queue jobs running; work not yet accepted is discarded. Abort does not implement withdrawal or remote deletion. Camera shutdown, navigation, participant withdrawal, and backend retention remain application responsibilities. `dispose()` is convenience cleanup, not a substitute for an explicitly awaited normal stop.

## 5. Connect upload tracking when needed

If your application waits for uploads, connect that tracker to logical artifact transitions. Keep the observer and its state alive beyond teardown because an in-flight upload can settle after abort returns:

```js
const pendingUploads = new Set(); // Application state outside the recording component.
function observeCapture(event) {
  if (event.type === 'artifact_registered') {
    pendingUploads.add(event.artifact.uploadId);
  } else if (event.type === 'artifact_settled') {
    pendingUploads.delete(event.artifact.uploadId);
  }
}
```

The library emits each registration and settlement once per upload ID, including for diagnostic timeline batches. You do not need to deduplicate retry progress or maintain a terminal-status list. Registration includes skipped artifacts and does not imply a write started. Settlement means an outcome exists, not that storage succeeded. Inspect `result.diagnosticUploads.artifacts` or the settled artifact when your UI needs diagnostic upload outcomes. Timeline files use the capture prefix, capture ID, and increasing batch number in their filenames; record sequence numbers preserve order across files.

If the host tracker uses numeric indexes, translate upload IDs into those indexes in the observer. That translation is application-specific. Raw `artifact` events retain retry diagnostics; `status` events describe capture state. Narrow explicitly by event type; see [events](api.md#events).

## 6. Check upload limits before deployment

Facecrop writes each AVI part, its matching JSON sidecar, and a final manifest through the configured transport. Before enabling recording, confirm that your storage path accepts the largest individual file and the total files accumulated for one participant's study result.

For JATOS deployments, check the configured maximum upload file size and study result size. Also check every reverse proxy between the browser and JATOS; for example, Nginx's `client_max_body_size` and request timeouts must allow the uploads through. Limits vary by deployment, so set them for your expected recording lengths and participant volume, then test a complete capture through the deployed study URL and verify that all parts and sidecars were saved.

## 7. Validate the deployed application

- Build with staging enabled and verify the complete hashed runtime is included.
- Open the actual root or nested study URL. Confirm runtime, worker, TensorFlow.js, WASM, and model requests resolve without HTML fallbacks or missing assets.
- Exercise startup on target browsers/devices, including unsupported capability and invalid setup reporting.
- Record and finalize a task. Check status, manifest persistence, AVI parts, and sidecars.
- Interrupt recording and a draining stop. Confirm cleanup targets the original session and late upload outcomes reach the tracker.
- Validate persistence through the actual transport. Package loading and bundling do not establish browser or backend behavior.

Use HTTPS or localhost. Keep orientation fixed: normalization is decided at startup and is not recorded frame by frame. Presentation gaps can result from analysis load, browser scheduling, or system load; they do not identify a single cause. Use `presentationTimeUs` and [output health evidence](metadata.md), rather than assuming every camera frame was captured.

The [Chromium acceptance checks](building.md#browser-acceptance) use a synthetic canvas stream. They complement application validation; they do not verify a physical camera or your JATOS deployment.
