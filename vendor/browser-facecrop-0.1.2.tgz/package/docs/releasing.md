# Preparing GitHub release artifacts

Browser facecrop is distributed from a checkout or a GitHub Release artifact;
it is not published to the npm registry. The package remains `private` to
prevent accidental registry publication.

Keep generated declarations current with `npm run build:types` and run
`npm run check:docs` before release packaging. The source annotations and
workflow are described in [the documentation guide](documentation.md).

## Keep the release record current

[RELEASES.md](../RELEASES.md) records release titles and publication status
separately. Use a descriptive title in each version heading; keep `Unreleased`,
`Tagged, not published`, or `Published` in a status field, never in place of the
title. Keep each GitHub release description in `releases/` alongside the code.
Update draft notes as changes land; do not bump the version merely to regenerate
an unpublished package. A tag alone is not evidence of GitHub publication.

Before packaging, finalize `releases/v${VERSION}.md` as the GitHub release body:
summarize the release, explain compatibility changes and known limitations, and
include the runtime asset-directory hash, attached asset names, and checksum command.
Do not put tag or publication state, local test reports, or local upload status in
the body. Publish this file as the GitHub release body (for example, use
`--notes-file releases/v${VERSION}.md` with `gh release create`); do not generate a
separate competing description. Until publication, keep the index's release title
in its heading and mark its status as unreleased or tagged-but-unpublished.

After publication, update the index with the actual title, publication timestamp,
prerelease status, tag commit, asset names/sizes, and SHA-256 values returned by
GitHub. Existing published notes are mirrored verbatim; copy any deliberate edits
made on GitHub back into the corresponding versioned file and commit the update.

## Create and verify the package

Start from the commit intended for release. For the initial release, use the
existing `0.1.0` version in `package.json` and create tag `v0.1.0`; no version
bump is needed. For each later release, choose a new package version and update
both `package.json` and `package-lock.json` together, for example:

```sh
npm version 0.1.2 --no-git-tag-version
```

Replace `0.1.2` with the intended version. Commit any version change before
tagging. Set `VERSION` to the package version being released (for the initial
release, `0.1.0`), then run the checks and create the artifact:

```sh
VERSION=0.1.2
npm ci
npm test
# For runtime/browser changes, also run Chromium acceptance from docs/building.md.
mkdir -p release-artifacts
npm pack --pack-destination release-artifacts
```

The `prepack` lifecycle builds `dist/` and verifies its asset manifest before
`npm pack` creates the tarball. The artifact name is
`release-artifacts/browser-facecrop-${VERSION}.tgz`. Inspect the printed
package contents and create a checksum alongside it:

```sh
VERSION=0.1.2
shasum -a 256 "release-artifacts/browser-facecrop-${VERSION}.tgz" \
  > "release-artifacts/browser-facecrop-${VERSION}.tgz.sha256"
```

Before uploading, verify the tarball in a clean temporary consumer project:

```sh
set -eu
VERSION=0.1.2
consumer_dir="$(mktemp -d)"
trap 'rm -rf "$consumer_dir"' EXIT
archive="$(pwd)/release-artifacts/browser-facecrop-${VERSION}.tgz"
(
  cd "$consumer_dir"
  npm init -y >/dev/null
  npm install "$archive"
  node -e "const api = require('browser-facecrop'); if (typeof api.createCaptureSession !== 'function') process.exit(1); require.resolve('browser-facecrop/react');"
  test -f node_modules/browser-facecrop/dist/facecrop.worker.js
  test -f node_modules/browser-facecrop/dist/asset-manifest.json
  node -e "require.resolve('browser-facecrop/scripts/stage-distribution.cjs'); require.resolve('browser-facecrop/scripts/verify-distribution.cjs');"
  node <<'NODE'
  const assert = require('assert');
  const fs = require('fs');
  const os = require('os');
  const path = require('path');
  const packageRoot = path.dirname(require.resolve('browser-facecrop/package.json'));
  const {stageDistribution} = require('browser-facecrop/scripts/stage-distribution.cjs');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'facecrop-consumer-stage-'));
  try {
    const result = stageDistribution(path.join(packageRoot, 'dist'), {
      generatedDirectory: path.join(root, 'generated'),
      publicRoot: path.join(root, 'public/assets/facecrop'),
      publicSubpath: '/assets/facecrop/',
      workRoot: root
    });
    assert(fs.existsSync(path.join(root, 'generated/facecrop.js')));
    assert(fs.existsSync(path.join(root, 'generated/facecropAssets.json')));
    assert(fs.existsSync(path.join(root, 'public/assets/facecrop', result.assetDirectory, 'facecrop.worker.js')));
  } finally {
    fs.rmSync(root, {recursive: true, force: true});
  }
NODE
)
```

Starting with 0.1.2, the package includes the reusable staging helper and its
distribution verifier. The consumer check above exercises the helper from the
packed artifact against its installed distribution; applications should call
it with their own generated-entry directory, public asset root, URL prefix and
work directory.

From the source checkout, check the installed package's declarations and Markdown
links using its actual package root:

```sh
node scripts/check-docs.cjs --package-root /absolute/path/to/consumer/node_modules/browser-facecrop
```

This command uses the source checkout's TypeScript and consumer fixtures against
the installed artifact. It does not require contributor scripts inside the package.

The installed package provides the API and runtime files, but the consuming
study still needs to serve them at a stable public URL and pass its absolute
directory URL as `assetBaseUrl`. Follow the [integration guide](integration.md).
The [build guide](building.md#browser-acceptance) documents Chromium acceptance;
the consuming application additionally checks its own production bundle and
deployment mount.

## Update the GitHub Release

Create the Git tag `v${VERSION}` and a matching GitHub Release for the version
committed above; do not move or replace an existing release tag. Attach both the
`.tgz` and its `.sha256` checksum file, and include the package version and
asset-directory hash from `dist/asset-manifest.json` in the release notes. Keep
the generated tarball out of git; `release-artifacts/` is ignored.

Do not run `npm publish`. For a consumer using the downloaded artifact, add a
local tarball dependency such as:

```json
{
  "dependencies": {
    "browser-facecrop": "file:vendor/browser-facecrop-0.1.2.tgz"
  }
}
```

Replace `0.1.2` with the released version in the filename. The `file:` path is
relative to the consuming project's `package.json`.

Repack after documentation or example changes, and regenerate the tarball checksum.
Those files are outside the runtime asset hash, so that hash can remain unchanged
while the release checksum changes. Include staging-helper availability, changed
defaults, and API additions in release notes. New artifact event kinds expand the
event union: consumers must explicitly narrow by `event.type` rather than assuming
every non-`artifact` event is a status event.
