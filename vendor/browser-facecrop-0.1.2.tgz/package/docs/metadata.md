# Reading facecrop output

Each capture produces gzip-compressed square BGR24 AVI parts (72×72 by default), one JSON sidecar per part, and a final manifest. Start with the manifest's `summary`, then follow `analysis.parts` to the video and frame metadata. The summary includes `faceDetectionMisses` as a quick count; the complete detection and health metrics remain in `validity.health`. A sidecar's `analysis.frames` maps each AVI frame to its presentation timestamp and the face/crop evidence used to produce it.

The schemas are `face-crop-manifest-v1` and `face-crop-events-v3`. The AVI format is `patch-video-avi-gzip-bgr24-v1` for 72×72 output and `patch-video-avi-gzip-bgr24-v2` for other dimensions. Manifest and sidecar metadata record output dimensions and part-size behavior. Consumers must check each AVI format identifier and use the dimensions recorded with that capture; do not assume a fixed 72×72 frame size. The Python reader selects its AVI parser and frame dimensions from each capture's manifest and sidecar metadata, supporting both format identifiers.

## Output resolution and part size

Set `config.output.resolution` to an integer from 16 through 512, divisible by four. It sets both output dimensions. Larger crops use more per-frame memory, worker time, and storage; resizing beyond the source detail does not create image information. The default 72 keeps format v1. Other dimensions use AVI format v2, while sidecars remain schema v3 and manifests remain schema v1 with additive output and part-behavior metadata.

`config.output.maxPartMiB` defaults to 4 MiB. One MiB is 1,048,576 bytes; fractional MiB values are rounded down to whole bytes (for example, `0.1` MiB becomes 104,857 bytes). The setting ranges from 0.03125 to 32 MiB and caps each encoded `.avi.gz` part. Explicit `null` selects the legacy raw-frame budget instead. The library computes a conservative maximum part frame count from raw AVI size, including the 232-byte header and 24 bytes per frame for index/chunk overhead, then bounds stored-DEFLATE gzip size using `S + 18 + 5 × ceil(S / 65535)`. It uses native `CompressionStream` normally, falls back to stored DEFLATE if native compression exceeds the requested ceiling, and checks the actual final size before upload. This conservative bound leaves some compression savings unused. The limit excludes sidecars, manifests, and diagnostic timeline files. A value unable to hold two frames plus their AVI and gzip overhead is rejected. The persisted `analysis.output.partSize.maxPartBytes` field continues to report the effective byte ceiling.

With the default 4 MiB ceiling, a 72×72 part holds at most 269 frames. Setting `maxPartMiB` to `null` restores the 8,382,528-byte raw output budget: it holds 539 frames at 72×72 and fewer frames at larger resolutions. Smaller part limits increase part count, upload requests, and index overhead. Parts are sealed at the calculated frame bound; the encoder does not adaptively split or re-encode a part to satisfy a larger budget.

## Analysis

Use `presentationTimeUs` for timing, in microseconds on the browser's monotonic presentation clock. It is not an epoch timestamp. `wallClockMs` is the browser's callback-receipt time in epoch milliseconds; it is not a sensor timestamp. Frames can be skipped under load, so AVI's nominal frame rate does not replace the per-frame timestamps. `precedingFramePresentationTimeUs` carries cadence across part boundaries.

Each frame retains its zero-based index, source dimensions, detection evidence, selected box and confidence, and the square ROI actually used. The states mean:

- `default`: no usable detection yet; use a centered square.
- `largest`: use the largest eligible face detection.
- `held`: retain the last valid crop during a detection gap.
- `reacquired`: a usable detection follows a gap.

Face selection does not track identity. A held crop has no expiry. Detection quality must be interpreted separately from capture integrity; a valid frame can use a default or held crop.

## Validity and health

The manifest's `validity` records effective configuration, detector/runtime versions, source and normalization decisions, and per-part persistence outcomes. Its `health` preserves frame counts, detection/miss counts, processing/encoding timing summaries, and warmup summaries without enabling verbose diagnostics.

An incomplete capture caused by source loss or dimensions outside supported bounds records an additive `summary.failureCode` and `validity.sourceFailure` snapshot. `VIDEO_TRACK_ENDED` means every video track exposed by the source stream reported `readyState: "ended"`; it identifies the observed lifecycle state, not whether the application, participant, or device ended the track. `VIDEO_STREAM_INACTIVE` means the associated stream reports inactive, including when cleanup has already removed its track objects. Its reason, “Video stream was inactive when capture stopped,” reports the observed state and does not identify what stopped the stream. `VIDEO_DIMENSIONS_UNSUPPORTED` means positive dimensions are outside the supported range. `VIDEO_DIMENSIONS_UNAVAILABLE` means dimensions are absent without evidence that the stream is inactive or all video tracks have ended. The snapshot preserves observed dimensions/readiness and the last valid dimensions. The generic `summary.reasonCode` remains `CAPTURE_INCOMPLETE`, and older readers can ignore these additive fields.

`health.accounting` counts submitted, processed, sealed, encoded, and persisted frames. Processing/encoding/persistence failures and discarded work are distinct. At normal finalization, `reconciliation.checks` verifies the stage equations. `consistent` means these counts reconcile; it does not mean every operation succeeded. Always also check `summary.status` and artifact outcomes.

The additive `reconciliation.checks.counts` flag reports whether accepted-frame and stage counters are nonnegative safe integers; `checks` and `consistent` are only populated for normal finalization, while aborted captures leave reconciliation absent (not performed).

`callbackGaps` counts browser presentation-counter gaps between observed callbacks. It does not identify camera loss, browser scheduling, or CPU pressure as the cause. Queue-wait totals measure time blocked on analysis or encoding capacity. These metrics do not describe all hardware frames or establish physiological signal quality.

A video part counts as persisted only when its AVI and sidecar writes both resolve. If any required output or the final manifest fails to persist, the returned session result is incomplete. The stored manifest cannot attest to its own subsequent write outcome; check the result's `manifest` and `artifacts` for that.

## Diagnostics and failure results

Verbose diagnostics are disabled by default. Set `config.uploadDiagnostics: true` to collect troubleshooting details, log them to the console, and upload an incremental timeline. The configuration key is named `uploadDiagnostics`; the existing manifest output field remains named `diagnostics` for compatibility. Scientific provenance and health summaries are always retained.

With upload diagnostics enabled, each session produces immutable JSON timeline batches named `<prefix>_<captureId>_diagnostics_000001.json`, with an increasing batch number. Each batch uses schema `face-crop-diagnostics-v1` and includes capture/context information, sequence bounds, dropped-record count, and ordered records. The library flushes at 64 KiB, when the page becomes hidden or exits, or after five seconds with buffered records; records arriving during a write are sent in the next batch. Batches are at most 64 KiB; records are limited to 32 KiB and the unsent buffer to 256 KiB. Oversized records receive an explicit truncation marker. Overflow drops the oldest unsent records and increments `result.diagnosticUploads.droppedRecords`; sequence gaps expose loss. Diagnostic files use the normal artifact lifecycle notifications and retry policy, but their notifications are not recorded into the timeline.

Construction does not write. `prepare()` collects diagnostic records in memory without persistence; `start()` enables timeline uploads, including records collected during preparation. Without a shared upload queue, unsupported startup and normal `stop()` await pending diagnostic uploads so their outcome is available in the returned result. With a shared queue, terminal operations wait for diagnostic batches to be accepted by the queue; their uploads can settle later. Diagnostic upload failure does not change capture status. Without a shared queue, `abort()` stops new diagnostic writes and retries and discards unsent diagnostic records; already-started writes can still settle and remain observable. With a shared queue, accepted diagnostic jobs continue after abort, while batches not yet accepted are discarded. Abrupt page exit can lose buffered, queued, or in-flight records. Public diagnostic artifact snapshots contain filenames, statuses, and attempt counts; internal completion promises are not exposed. A rejected write can be `uncertain` because the server may have saved data before the response was lost. The application is responsible for deletion and participant withdrawal policy.

An AVI part is uploaded before its face-events sidecar. If AVI retries exhaust without abort, the sidecar is `not_attempted` with zero attempts; this differs from `discarded`, which means abort prevented the write from starting. The logical part remains `failed`. Host trackers should consume `artifact_registered` and `artifact_settled` and use the reported `not_attempted` status; the library does not mark a host-side tracker entry failed. A rejected AVI write remains `uncertain`, since the server may have stored it despite the rejected response. Readers should accept `not_attempted` as an additive artifact outcome; older stored manifests may still use `failed` with zero attempts for this case.

## Migrating older metadata

| Previous path | New path |
|---|---|
| Manifest `status`, `reason` | `summary.status`, `summary.reason` |
| Manifest `output`, `parts` | `analysis.output`, `analysis.parts` |
| Manifest `statistics` | `validity.health` |
| Manifest `configuration`, `source` | `validity.configuration`, `validity.source` |
| Manifest configuration normalization | `validity.frameNormalization` |
| Full `capability` probe dumps | Compact `validity.capability`; verbose `diagnostics.capability` when enabled |
| Sidecar `frames` | `analysis.frames` |
| Sidecar `selectionConfiguration` | `validity.selectionConfiguration` |

Obsolete delegate/suppression requests are removed because they did not alter the WASM detector. Study recording modes remain application policy and are not scientific configuration.

The stored-block envelope follows [RFC 1951](https://www.rfc-editor.org/rfc/rfc1951.html#section-3.2.4) and the gzip wrapper/trailer in [RFC 1952](https://www.rfc-editor.org/rfc/rfc1952.html#section-2.3.1). It is a bound for the library's deterministic stored-block fallback, rather than an assumption about an arbitrary compressor.
