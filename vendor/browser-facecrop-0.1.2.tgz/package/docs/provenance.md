# Import provenance

This repository imports the corrected facecrop snapshot from [openDST commit 3d2258886e13f722d82464ccb7b685c832007f0b](https://github.com/mbp-lab/openDST/tree/3d2258886e13f722d82464ccb7b685c832007f0b/facecrop), recorded on 2026-10-07. The original authorship and development history remain available in [the source history](https://github.com/mbp-lab/openDST/commits/3d2258886e13f722d82464ccb7b685c832007f0b/facecrop). These commits import existing capabilities; their messages describe the intent of those capabilities rather than claim new development.

## Reading the opening history

The import grows in dependency order, pairing existing implementation slices with the tests that can exercise them. Large worker and output files span several commits so blame can distinguish crop selection, scientific encoding, worker ownership, ordering, and storage behavior. The controller state machine is imported together because its scheduling and terminal transitions are connected. Configuration first arrives with controller tests, then becomes part of the public session API.

| Commit | Responsibility |
|---|---|
| `a35d023` | Establish the library license and reproducible development toolchain |
| `8114117` | Normalize native camera pixels into the presented orientation |
| `70f48cd` | Select stable face regions and resample deterministic patches |
| `f920085` | Encode lossless video with frame-level timing evidence |
| `5a4a4c1` | Bound video parts and separate changes in source geometry |
| `af7312d` | Detect faces on normalized frames with pinned worker assets |
| `6045403` | Assemble parallel analysis results in source order |
| `8cdf533` | Bound persistence and report video and sidecar outcomes separately |
| `abaa828` | Probe capture support and define transferred frame ownership |
| `192250f` | Coordinate capture shutdown and reconcile processing outcomes |
| `9b1b303` | Expose an application-owned capture session and explicit transport |
| `715f968` | Build and verify the browser runtime as one distribution |
| `c3f671d` | Stage matching library entries and immutable runtime assets |
| Final import commit | Document standalone reuse and browser acceptance checks |

The completed import preserves runtime source, lockfile, model, and license bytes from the source snapshot, together with its original unit test cases. Staging also includes a module bridge and regression for CRA production bundling; this fixes an interoperability bug discovered while exercising the extracted library in the complete study. Intermediate imports are adjusted until their dependencies arrive; there are no placeholder implementations. Every implementation commit passed its present unit tests. Build and distribution verification start with the build-tooling commit.

## Earlier fixes and historical evidence

The import messages point to original fixes for completed payload and unattempted-sidecar handling (225b8a0), transport acknowledgement release (fcae374), unsuccessful frame transfers (e298605), accounting domains (f8e257b), and verified build/staging (74ee026). Follow those revisions in the source repository for the actual development context.

Historical campaign reports, the synthetic output corpus, and study acceptance evidence stay in [openDST's campaign archive](https://github.com/mbp-lab/openDST/tree/rppg-downsampled-stream/docs/facecrop-history). Their hashes, paths, test counts, and environment measurements describe dated checkpoints. They do not establish new physical-camera, production-JATOS, or npm-package support claims. The study-specific browser/JATOS harness lives in openDST under tests/facecrop/browser-jatos.cjs.

## Retention diagnostic

Run the current sink diagnostic from this standalone checkout:

```sh
node --expose-gc scripts/retention-baseline.cjs --echo-payload
```

Baseline mode deliberately references the original openDST history at 4fd85bc6e031f33f3dd3aad6207e25b69fd8d595 and its old facecrop/src paths. A standalone clone does not contain that history. Supply either an original repository containing that revision or an exported snapshot with a src directory:

```sh
node --expose-gc scripts/retention-baseline.cjs --baseline --baseline-repository /path/to/openDST
node --expose-gc scripts/retention-baseline.cjs --baseline --baseline-source /path/to/source-snapshot
```

This diagnostic uses synthetic encoded bytes and realistic metadata in Node; browser heap and camera behavior require the browser checks.
