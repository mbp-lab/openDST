# Facecrop browser library

## Purpose

Facecrop adds an optional, on-device recording path for browser studies that need face-region footage for remote photoplethysmography (rPPG) analysis. It detects and crops the face, downsamples frames to square BGR24 output (72×72 by default), and saves gzip-compressed AVI with lossless pixel encoding and timestamped crop metadata. Output resolution and an optional encoded part-size ceiling in MiB are configurable.

Use it when your analysis needs more image fidelity than ordinary lossy MP4/WebM recording preserves. It produces an additional analysis recording alongside the study's regular video. The core has no React or study-framework dependency: you supply an existing video element and a persistence transport.

### Essential constraints

- Use HTTPS or localhost and a browser supporting the required video-frame and worker APIs. Startup checks support; test on your target devices.
- Set device orientation before capture and keep it fixed. Startup normalization is reused; orientation changes can produce a stale transform or an incomplete recording.
- Cropping discards spatial detail, and frames can be skipped under load. Use timestamps and [output health information](docs/metadata.md) when interpreting recordings.
- The application owns camera permission/tracks and recording boundaries. A session-scoped capture awaits uploads at stop; studies sharing an upload queue can let uploads continue across task transitions.

## Getting started

**Release package:** download the versioned `.tgz` and `.sha256` from [GitHub Releases](https://github.com/mbp-lab/browser-facecrop/releases), verify the checksum, and install the tarball as a local dependency. It includes the built runtime, declarations, and staging helper; you do not need to build the library. Follow the [integration guide](docs/integration.md).

**Source checkout:** build the distribution using the [contributor build guide](docs/building.md), then follow the same integration guide. Node 22/npm 10 is the supported project toolchain; the build guide distinguishes tooling from browser requirements.

### Minimal capture

After deployment, `Facecrop` is the loaded core API, `video` is your existing playing video element, and `assetBaseUrl` is the absolute URL of the staged runtime directory. Your application provides `saveStudyArtifact(filename, payload)`, whose promise resolves after persistence.

```js
const session = Facecrop.createCaptureSession({
  video,
  assetBaseUrl,
  filenamePrefix: 'speech',
  context: {task: 'speech'},
  transport: {
    write: ({filename, payload}) => saveStudyArtifact(filename, payload)
  }
});

const started = await session.start(); // Includes preparation.
if (started.status !== 'capturing') {
  console.warn('Facecrop did not start', started.reason, started.reasonCode);
}
```

At normal task completion, finalize before advancing:

```js
const finalized = await session.stop();
// Inspect finalized.status and artifact outcomes before deciding how to proceed.
```

For a multi-task study, create one queue per study page and pass it to each session. In this mode, `stop()` drains capture processing and queues its artifacts and manifest, while upload events continue to report real network settlement. The queue is memory-only and does not survive page closure.

```js
const uploadQueue = Facecrop.createUploadQueue({transport});
const taskSession = Facecrop.createCaptureSession({video, assetBaseUrl, uploadQueue});
```

Construction can throw for invalid inputs; runtime failures usually resolve structured results. The [lifecycle walkthrough](docs/integration.md#4-connect-the-capture-lifecycle) explains failure handling and interrupted teardown. Explicit `prepare()` is optional when you want a readiness check before recording begins.

Set `config.uploadDiagnostics: true` to log troubleshooting events and upload an ordered diagnostic timeline through the configured transport. Diagnostic files are sent in opportunistic batches, and their results are available in `result.diagnosticUploads`; see the [API reference](docs/api.md#configuration) and [output guide](docs/metadata.md#diagnostics-and-failure-results).

### Integration checklist

1. **Install and pin** a verified release package or build a source checkout.
2. **Stage the entry and runtime assets** and supply their deployed absolute URL.
3. **Supply inputs:** existing video, transport, context, and optional configuration.
4. **Connect the lifecycle:** inspect startup, await normal stop, abort interrupted teardown.
5. **Track uploads if needed:** consume registration and settlement events.
6. **Validate deployment:** exercise runtime loading and persistence on the actual study URL.

Each step is explained in order in [Integrating browser-facecrop](docs/integration.md).

## Detailed guides and examples

| Task | Read next |
|---|---|
| Install, stage, and integrate into an application | [Integration guide](docs/integration.md) |
| Look up options, configuration, lifecycle, results, or events | [API reference](docs/api.md) |
| Use the optional React hook | [React guide](react/README.md) and [React example](examples/react/FacecropRecorder.jsx) |
| Integrate a plain browser/JATOS page | [Plain-browser example](examples/plain-browser/index.html) |
| Interpret recordings, timestamps, and validity evidence | [Output guide](docs/metadata.md) |
| Read output in Python | [Python reader guide in the source repository](https://github.com/mbp-lab/browser-facecrop/blob/main/python/README.md) |

React 16.8 through 19 is an optional peer dependency. The Python reader is a separate package, available under `python/` in a source checkout; it is not included in the JavaScript release tarball.

## Contributor information

- [Build, toolchain, and browser acceptance](docs/building.md)
- [Documentation and declaration workflow](docs/documentation.md)
- [Release history and unreleased notes](RELEASES.md)
- [GitHub release packaging](docs/releasing.md)
- [Processing and scientific contract](docs/processing.md)
- [Known limitations and follow-up work](docs/backlog.md)
- [Import provenance and earlier validation evidence](docs/provenance.md)

## Licensing

The library source is GPL-3.0-only. TensorFlow.js, its WASM backend, BlazeFace, and the bundled model use Apache-2.0. The distribution includes third-party license text and notices.
